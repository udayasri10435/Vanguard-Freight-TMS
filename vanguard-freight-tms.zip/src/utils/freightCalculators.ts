// Freight logistics calculations and formatting helpers

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function formatNumber(val: number): string {
  return new Intl.NumberFormat('en-US').format(val);
}

export function calculateRPM(rate: number, miles: number): string {
  if (!miles || miles <= 0) return '$0.00';
  return `$${(rate / miles).toFixed(2)}`;
}

export function calculateMargin(shipperRate: number, carrierRate: number): {
  marginDollars: number;
  marginPct: number;
  status: 'healthy' | 'moderate' | 'thin' | 'negative';
} {
  const marginDollars = shipperRate - carrierRate;
  const marginPct = shipperRate > 0 ? (marginDollars / shipperRate) * 100 : 0;

  let status: 'healthy' | 'moderate' | 'thin' | 'negative' = 'healthy';
  if (marginPct >= 16) status = 'healthy';
  else if (marginPct >= 10) status = 'moderate';
  else if (marginPct > 0) status = 'thin';
  else status = 'negative';

  return { marginDollars, marginPct, status };
}

// Approximate distance calculator for major US freight hubs
const CITY_COORDINATES: Record<string, { lat: number; lng: number }> = {
  'chicago, il': { lat: 41.8781, lng: -87.6298 },
  'elgin, il': { lat: 42.0354, lng: -88.2826 },
  'atlanta, ga': { lat: 33.749, lng: -84.388 },
  'dallas, tx': { lat: 32.7767, lng: -96.797 },
  'fort worth, tx': { lat: 32.7555, lng: -97.3308 },
  'salinas, ca': { lat: 36.6777, lng: -121.6555 },
  'los angeles, ca': { lat: 34.0522, lng: -118.2437 },
  'savannah, ga': { lat: 32.0809, lng: -81.0912 },
  'memphis, tn': { lat: 35.1495, lng: -90.049 },
  'allentown, pa': { lat: 40.6084, lng: -75.4902 },
  'charlotte, nc': { lat: 35.2271, lng: -80.8431 },
  'laredo, tx': { lat: 27.5036, lng: -99.5076 },
  'detroit, mi': { lat: 42.3314, lng: -83.0458 },
  'nashville, tn': { lat: 36.1627, lng: -86.7816 },
  'kansas city, mo': { lat: 39.0997, lng: -94.5786 },
  'denver, co': { lat: 39.7392, lng: -104.9903 },
  'phoenix, az': { lat: 33.4484, lng: -112.074 },
  'seattle, wa': { lat: 47.6062, lng: -122.3321 },
};

export function estimateHighwayMiles(originCity: string, destCity: string): number {
  const normOrigin = originCity.toLowerCase().trim();
  const normDest = destCity.toLowerCase().trim();

  const c1 = CITY_COORDINATES[normOrigin];
  const c2 = CITY_COORDINATES[normDest];

  if (!c1 || !c2) {
    // default realistic estimate
    return 650;
  }

  // Haversine formula * 1.18 road curvature factor
  const R = 3958.8; // Radius of the Earth in miles
  const dLat = ((c2.lat - c1.lat) * Math.PI) / 180;
  const dLon = ((c2.lng - c1.lng) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((c1.lat * Math.PI) / 180) *
      Math.cos((c2.lat * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const directMiles = R * c;
  return Math.round(directMiles * 1.18);
}

export function estimateBenchmarkRate(miles: number, equipment: string): number {
  let baseRpm = 3.20;
  if (equipment.includes('Reefer')) baseRpm = 3.65;
  if (equipment.includes('Flatbed')) baseRpm = 3.75;
  if (equipment.includes('Step Deck')) baseRpm = 4.10;
  
  // Shorter lanes have higher RPM minimums
  if (miles < 400) baseRpm += 0.80;
  
  return Math.round(miles * baseRpm);
}
