import React from 'react';
import { Load, Carrier, SettlementRecord } from '../types/freight';
import { formatCurrency } from '../utils/freightCalculators';
import { Printer, Download, X, CheckCircle2, ShieldCheck, FileText } from 'lucide-react';

interface DocumentModalProps {
  type: 'RATE_CON' | 'SETTLEMENT_VOUCHER' | 'SHIPPER_INVOICE';
  load?: Load;
  carrier?: Carrier;
  settlement?: SettlementRecord;
  onClose: () => void;
}

export const DocumentModal: React.FC<DocumentModalProps> = ({
  type,
  load,
  carrier,
  settlement,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const isRateCon = type === 'RATE_CON';
  const isSettlement = type === 'SETTLEMENT_VOUCHER';
  const isInvoice = type === 'SHIPPER_INVOICE';

  const docTitle = isRateCon
    ? 'BROKER-CARRIER RATE CONFIRMATION'
    : isSettlement
    ? 'CARRIER SETTLEMENT & REMITTANCE ADVICE'
    : 'FREIGHT TRANSPORTATION INVOICE';

  const docNumber = isRateCon
    ? load?.rateConNumber || `RC-VG-${load?.loadNumber || '8901'}`
    : isSettlement
    ? settlement?.voucherNumber || 'VCH-2026-0984'
    : settlement?.invoiceNumber || `INV-VG-${load?.loadNumber || '8901'}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden my-8">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-blue-400" />
            <div>
              <h2 className="text-sm font-semibold text-white tracking-wide">{docTitle}</h2>
              <p className="text-xs text-slate-400 font-mono">Reference #{docNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Close document"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Paper View (White parchment look for authentic legal doc) */}
        <div className="p-8 sm:p-12 bg-white text-slate-900 font-sans max-h-[80vh] overflow-y-auto print:max-h-none print:p-0 print:m-0 print:overflow-visible text-xs leading-relaxed">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start pb-6 border-b-2 border-slate-900 gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold tracking-tight text-slate-950 font-sans">
                  VANGUARD FREIGHT
                </span>
                <span className="text-[10px] tracking-widest uppercase font-mono px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                  LOGISTICS TMS
                </span>
              </div>
              <p className="text-slate-600 mt-1 font-mono text-[11px]">
                FMCSA Property Broker License: MC-994102-B · USDOT 3921008
              </p>
              <p className="text-slate-500 text-[11px]">
                300 N LaSalle Dr, Suite 2400 · Chicago, IL 60654
              </p>
              <p className="text-slate-500 text-[11px]">
                24/7 Dispatch: (800) 555-8264 · settlements@vanguardfreight.com
              </p>
            </div>

            <div className="text-right sm:text-right font-mono">
              <div className="text-lg font-bold text-slate-950 uppercase">{docTitle}</div>
              <div className="mt-1 text-slate-800">
                <span className="font-semibold">DOC #:</span> {docNumber}
              </div>
              <div className="text-slate-600">
                <span className="font-semibold">DATE:</span> {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
              </div>
              <div className="text-slate-600">
                <span className="font-semibold">LOAD REF:</span> {load?.loadNumber || settlement?.loadNumber || 'VG-8901'}
              </div>
            </div>
          </div>

          {/* Carrier & Shipper Entities */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6 p-4 bg-slate-50 border border-slate-200 rounded">
            <div>
              <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1 font-mono">
                {isInvoice ? 'BILL TO (SHIPPER / CUSTOMER)' : 'CARRIER CONTRACTOR INFORMATION'}
              </div>
              {isInvoice ? (
                <div>
                  <div className="text-sm font-bold text-slate-950">
                    {load?.shipperName || settlement?.shipperName || 'Midwest Automotive Supply Corp'}
                  </div>
                  <div className="text-slate-600 text-[11px]">Accounts Payable Dept · AP Code: VNG-889</div>
                  <div className="text-slate-600 text-[11px]">Payment Terms: Net 30 Days</div>
                </div>
              ) : (
                <div>
                  <div className="text-sm font-bold text-slate-950">
                    {carrier?.legalName || load?.assignedCarrierName || settlement?.carrierName || 'Blue Ridge Freight Lines LLC'}
                  </div>
                  <div className="text-slate-700 font-mono text-[11px]">
                    MC#: {carrier?.mcNumber || load?.assignedCarrierMc || settlement?.carrierMc || 'MC-849201'} · DOT#: {carrier?.dotNumber || 'USDOT-3109442'}
                  </div>
                  <div className="text-slate-600 text-[11px]">
                    Dispatcher: {carrier?.contactName || 'Marcus Vance'} · Phone: {carrier?.phone || '(423) 555-8912'}
                  </div>
                  <div className="text-slate-600 text-[11px]">
                    Driver: {load?.driverName || 'Assigned Driver'} · Cell: {load?.driverPhone || 'On File'}
                  </div>
                </div>
              )}
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1 font-mono">
                EQUIPMENT & COMMODITY REQUIREMENTS
              </div>
              <div className="text-slate-800">
                <span className="font-semibold">Equipment:</span> {load?.equipment || settlement?.equipment || 'Dry Van 53\''}
              </div>
              <div className="text-slate-800">
                <span className="font-semibold">Commodity:</span> {load?.commodity || 'General Freight / Non-Hazmat'}
              </div>
              <div className="text-slate-800">
                <span className="font-semibold">Weight:</span> {load?.weightLbs ? `${load.weightLbs.toLocaleString()} lbs` : '41,200 lbs'} ({load?.palletCount || 24} Pallets)
              </div>
              {load?.tempRequirement && (
                <div className="text-red-700 font-semibold">
                  <span>Temperature Requirement:</span> {load.tempRequirement}
                </div>
              )}
            </div>
          </div>

          {/* Lane Itinerary: Origin and Destination */}
          <div className="space-y-4 my-6">
            <div className="text-xs font-bold text-slate-900 uppercase font-mono tracking-wider">
              ROUTE ITINERARY & APPOINTMENT SCHEDULE
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Stop 1: Pickup */}
              <div className="p-4 border border-slate-200 rounded bg-slate-50/50">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200">
                  <span className="font-bold text-slate-900 font-mono">STOP 1 · SHIPPER (ORIGIN)</span>
                  <span className="text-[10px] bg-blue-100 text-blue-800 font-mono px-1.5 py-0.5 rounded">PICKUP</span>
                </div>
                <div className="font-semibold text-slate-900 text-xs">
                  {load?.origin.facilityName || 'Midwest DC Plant #4'}
                </div>
                <div className="text-slate-600 text-[11px]">
                  {load?.origin.city || 'Elgin'}, {load?.origin.state || 'IL'} {load?.origin.zip || '60123'}
                </div>
                <div className="mt-2 text-slate-800 text-[11px]">
                  <span className="font-semibold">Appointment:</span> {load?.origin.appointmentTime || 'Tomorrow 08:00 CDT'}
                </div>
                <div className="text-slate-600 text-[11px]">
                  <span className="font-semibold">Contact:</span> {load?.origin.contactPhone || '(847) 555-0199'}
                </div>
                {load?.origin.notes && (
                  <div className="mt-1 text-[11px] text-amber-900 bg-amber-50 p-1.5 rounded border border-amber-200">
                    <span className="font-semibold">Special Instructions:</span> {load.origin.notes}
                  </div>
                )}
              </div>

              {/* Stop 2: Delivery */}
              <div className="p-4 border border-slate-200 rounded bg-slate-50/50">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-200">
                  <span className="font-bold text-slate-900 font-mono">STOP 2 · RECEIVER (DESTINATION)</span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-mono px-1.5 py-0.5 rounded">DELIVERY</span>
                </div>
                <div className="font-semibold text-slate-900 text-xs">
                  {load?.destination.facilityName || 'SouthEast Distribution Hub'}
                </div>
                <div className="text-slate-600 text-[11px]">
                  {load?.destination.city || 'Atlanta'}, {load?.destination.state || 'GA'} {load?.destination.zip || '30349'}
                </div>
                <div className="mt-2 text-slate-800 text-[11px]">
                  <span className="font-semibold">Appointment:</span> {load?.destination.appointmentTime || 'Oct 01, 14:00 EDT'}
                </div>
                <div className="text-slate-600 text-[11px]">
                  <span className="font-semibold">Contact:</span> {load?.destination.contactPhone || '(404) 555-8831'}
                </div>
                {load?.destination.notes && (
                  <div className="mt-1 text-[11px] text-amber-900 bg-amber-50 p-1.5 rounded border border-amber-200">
                    <span className="font-semibold">Special Instructions:</span> {load.destination.notes}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Rate & Line Items Table */}
          <div className="my-6">
            <table className="w-full text-left border-collapse border border-slate-300">
              <thead>
                <tr className="bg-slate-100 text-slate-800 font-mono text-[11px] uppercase">
                  <th className="border border-slate-300 p-2">Item Description</th>
                  <th className="border border-slate-300 p-2 text-center">Quantity / Miles</th>
                  <th className="border border-slate-300 p-2 text-right">Rate</th>
                  <th className="border border-slate-300 p-2 text-right">Total Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {isInvoice ? (
                  <>
                    <tr>
                      <td className="border border-slate-300 p-2 font-medium">
                        Standard Freight Linehaul ({load?.origin.city}, {load?.origin.state} to {load?.destination.city}, {load?.destination.state})
                      </td>
                      <td className="border border-slate-300 p-2 text-center">{load?.miles || 718} mi</td>
                      <td className="border border-slate-300 p-2 text-right">All-in</td>
                      <td className="border border-slate-300 p-2 text-right font-bold">
                        {formatCurrency(load?.shipperRate || settlement?.shipperTotalInvoiced || 2850)}
                      </td>
                    </tr>
                    {settlement && settlement.shipperTotalInvoiced > settlement.shipperBaseRate && (
                      <tr>
                        <td className="border border-slate-300 p-2 text-slate-700">
                          Authorized Accessorial: Receiver Facility Detention Re-bill
                        </td>
                        <td className="border border-slate-300 p-2 text-center">2.0 hrs</td>
                        <td className="border border-slate-300 p-2 text-right">$75.00/hr</td>
                        <td className="border border-slate-300 p-2 text-right font-bold">
                          {formatCurrency(settlement.shipperTotalInvoiced - settlement.shipperBaseRate)}
                        </td>
                      </tr>
                    )}
                  </>
                ) : (
                  <>
                    <tr>
                      <td className="border border-slate-300 p-2 font-medium">
                        Agreed Carrier Linehaul Transportation Rate
                      </td>
                      <td className="border border-slate-300 p-2 text-center">{load?.miles || 718} mi</td>
                      <td className="border border-slate-300 p-2 text-right">Contracted</td>
                      <td className="border border-slate-300 p-2 text-right font-bold">
                        {formatCurrency(load?.currentCarrierRate || settlement?.carrierBasePay || 2350)}
                      </td>
                    </tr>
                    {settlement?.accessorials.map((acc) => (
                      <tr key={acc.id}>
                        <td className="border border-slate-300 p-2 text-slate-700">
                          {acc.description}
                        </td>
                        <td className="border border-slate-300 p-2 text-center">1</td>
                        <td className="border border-slate-300 p-2 text-right">{formatCurrency(acc.amount)}</td>
                        <td className="border border-slate-300 p-2 text-right font-bold">{formatCurrency(acc.amount)}</td>
                      </tr>
                    ))}
                    {settlement?.quickPaySelected && (
                      <tr className="text-blue-900 bg-blue-50/50">
                        <td className="border border-slate-300 p-2 font-medium">
                          QuickPay Expedited ACH Transfer Discount (2.0% fee for same-day funding)
                        </td>
                        <td className="border border-slate-300 p-2 text-center">Same Day</td>
                        <td className="border border-slate-300 p-2 text-right">-2.0%</td>
                        <td className="border border-slate-300 p-2 text-right font-bold text-red-600">
                          -{formatCurrency(settlement.quickPayDiscount)}
                        </td>
                      </tr>
                    )}
                  </>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-mono text-xs font-bold">
                  <td colSpan={3} className="border border-slate-300 p-2 text-right uppercase">
                    {isInvoice ? 'Total Due Vanguard Freight:' : isSettlement ? 'Final Remittance Disbursement:' : 'Agreed Total Carrier Pay:'}
                  </td>
                  <td className="border border-slate-300 p-2 text-right text-sm text-slate-950">
                    {isInvoice
                      ? formatCurrency(load?.shipperRate || settlement?.shipperTotalInvoiced || 2850)
                      : isSettlement
                      ? formatCurrency(settlement?.finalCarrierPayout || 2350)
                      : formatCurrency(load?.currentCarrierRate || 2350)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Strict Anti-Double-Brokering and Detention Clauses */}
          <div className="p-4 my-6 bg-slate-50 border border-slate-200 rounded space-y-2 text-[10px] text-slate-600 font-mono">
            <div className="font-bold text-slate-900 uppercase">
              MANDATORY BROKER-CARRIER CONTRACT TERMS & ANTI-DOUBLE-BROKERING WARRANTY
            </div>
            <p>
              1. <strong className="text-slate-800">NO DOUBLE-BROKERING:</strong> Carrier explicitly agrees and warrants that it will transport this shipment exclusively on equipment operated under its own active FMCSA authority. Brokering, re-brokering, trip leasing, or assigning this load to any third party is STRICTLY PROHIBITED and constitutes material breach, resulting in complete forfeiture of freight charges and immediate reporting to TIA Watchdog and FMCSA.
            </p>
            <p>
              2. <strong className="text-slate-800">DETENTION POLICY:</strong> Detention begins after two (2) hours of free time from the confirmed scheduled appointment time. Carrier must notify Vanguard Dispatch at hour 1.5. Signed in and out times with receiver/shipper stamp on Bill of Lading (BOL) are mandatory to substantiate claims ($75.00/hour thereafter).
            </p>
            <p>
              3. <strong className="text-slate-800">SETTLEMENT REQUIREMENTS:</strong> Legible signed Proof of Delivery (POD), Bill of Lading (BOL), and this executed Rate Confirmation must be submitted via Vanguard TMS Settlement Portal within 24 hours of delivery.
            </p>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-8 pt-6 border-t border-slate-300">
            <div>
              <div className="text-[11px] font-bold text-slate-800 font-mono">AUTHORIZED BROKER SIGNATURE</div>
              <div className="mt-4 border-b border-slate-400 pb-1 flex items-center justify-between">
                <span className="font-serif italic text-base text-blue-900">J. Harrison, Senior Freight Broker</span>
                <ShieldCheck className="w-4 h-4 text-emerald-600 inline" />
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-1">Vanguard Freight Operations · Digital Verification #VG-VERIFIED</div>
            </div>

            <div>
              <div className="text-[11px] font-bold text-slate-800 font-mono">CARRIER ACCEPTANCE & DISPATCH SIGNATURE</div>
              <div className="mt-4 border-b border-slate-400 pb-1">
                <span className="font-serif italic text-base text-slate-900">
                  {carrier?.contactName || 'Marcus Vance'} (Signed via Vanguard Portal)
                </span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono mt-1">
                IP: 198.51.100.44 · Timestamp: {new Date().toLocaleTimeString()} EDT
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3 bg-slate-950 border-t border-slate-800 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Document verified against Vanguard Automated Vetting & Compliance Ledger</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors font-medium text-xs"
          >
            Close Document
          </button>
        </div>
      </div>
    </div>
  );
};
