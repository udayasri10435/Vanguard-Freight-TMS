import React, { useState } from 'react';
import { MarketLaneRate } from '../types/freight';
import { formatCurrency } from '../utils/freightCalculators';
import {
  Layers,
  ShieldAlert,
  ArrowRightLeft,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  GitBranch,
  Database,
  Truck,
  Building,
} from 'lucide-react';

interface FreightMarketInsightsProps {
  marketRates: MarketLaneRate[];
}

export const FreightMarketInsights: React.FC<FreightMarketInsightsProps> = ({ marketRates }) => {
  const [selectedCorridor, setSelectedCorridor] = useState<string>(marketRates[0]?.id || '');
  const activeRate = marketRates.find((m) => m.id === selectedCorridor) || marketRates[0];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-3">
        <div className="flex items-center gap-2">
          <GitBranch className="w-5 h-5 text-blue-400" />
          <h2 className="text-lg font-bold text-white tracking-tight">
            Digital Freight: The Fragmentation Crisis & Vanguard's Unified Operating Architecture
          </h2>
        </div>
        <p className="text-xs text-slate-300 max-w-4xl leading-relaxed">
          Despite billions invested in point solutions, the $800B freight brokerage market remains deeply fractured.
          Brokers copy-paste data between 4–7 incompatible software silos every hour. Vanguard TMS replaces this
          disjointed stack with a single unified operating fabric connecting load boards, FMCSA fraud shields,
          algorithmic rate negotiations, and automated settlement ledgers.
        </p>
      </div>

      {/* The 4 Core Fractures of Digital Freight */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Fracture 1 */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-blue-950 border border-blue-800 rounded-lg text-blue-400">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                  Fracture 01
                </span>
                <h3 className="text-sm font-bold text-white">Siloed Load Boards & Ghost Capacity</h3>
              </div>
            </div>
            <span className="text-[10px] font-mono text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-900">
              High Operational Drag
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Brokers manually post and un-post freight across DAT, Truckstop, and private load boards.
            When a load is booked, failure to immediately withdraw it triggers hundreds of dead phone calls,
            duplicate quotes, and accidental double-dispatch conflicts.
          </p>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Vanguard Solution: 1-Click Multi-Board Real-Time Webhook Syndication.</span>
          </div>
        </div>

        {/* Fracture 2 */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-red-950 border border-red-800 rounded-lg text-red-400">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                  Fracture 02
                </span>
                <h3 className="text-sm font-bold text-white">Double-Brokering & Chameleon Carriers</h3>
              </div>
            </div>
            <span className="text-[10px] font-mono text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-900">
              $700M Annual Loss
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Organized cargo theft syndicates purchase aged MC numbers or impersonate legitimate carriers,
            then re-broker shipments to unsuspecting third parties for cheap cash advances while cargo is held hostage.
          </p>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Vanguard Solution: Integrated FMCSA SAFER, Mailbox Flagging & Chameleon Scoring.</span>
          </div>
        </div>

        {/* Fracture 3 */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-950 border border-amber-800 rounded-lg text-amber-400">
                <ArrowRightLeft className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                  Fracture 03
                </span>
                <h3 className="text-sm font-bold text-white">Disjointed Email & Phone Rate Haggling</h3>
              </div>
            </div>
            <span className="text-[10px] font-mono text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-900">
              Margin Bleed
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Rate negotiations take place across fragmented email inboxes and phone calls without live visibility
            into real-time DAT spot indexes or current broker gross margins, causing brokers to overpay during spot spikes.
          </p>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Vanguard Solution: Dynamic Desk with Live Margin Analyzer & Canned Rate Scripts.</span>
          </div>
        </div>

        {/* Fracture 4 */}
        <div className="p-5 bg-slate-900/80 border border-slate-800 rounded-xl space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-950 border border-emerald-800 rounded-lg text-emerald-400">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                  Fracture 04
                </span>
                <h3 className="text-sm font-bold text-white">Carrier Cash Lag & Factoring NOA Conflicts</h3>
              </div>
            </div>
            <span className="text-[10px] font-mono text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-900">
              30–45 Day Delay
            </span>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed">
            Carriers wait over a month for paper checks while battling factoring companies over conflicting
            Notices of Assignment (NOA), and brokers lose margins when detention receipts aren't rebilled promptly.
          </p>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-slate-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Vanguard Solution: Automated 2% QuickPay ACH Disbursal & Factoring Registry Guard.</span>
          </div>
        </div>
      </div>

      {/* Real-Time Market Benchmark Corridor Matrix */}
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 gap-2">
          <div>
            <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wide">
              Live National Freight Corridor Rate & Capacity Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Real-time spot rate averages, Rate-per-Mile (RPM), and Outbound Tender Reject Indexes (OTRI).
            </p>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Source: Vanguard SONAR & DAT Benchmark Stream
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Corridor Selection List */}
          <div className="space-y-2">
            {marketRates.map((m) => {
              const isSelected = m.id === activeRate.id;
              return (
                <div
                  key={m.id}
                  onClick={() => setSelectedCorridor(m.id)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-blue-500 shadow-sm'
                      : 'bg-slate-950 border-slate-800 hover:bg-slate-850'
                  }`}
                >
                  <div className="font-semibold text-xs text-white">{m.lane}</div>
                  <div className="flex items-center justify-between mt-1 text-[11px] font-mono text-slate-400">
                    <span>
                      {m.equipment} · {m.miles} mi
                    </span>
                    <span className="text-white font-bold">{formatCurrency(m.spotAverage)}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Active Corridor Analytics Spotlight */}
          <div className="lg:col-span-2 p-5 bg-slate-950 border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-mono text-blue-400 uppercase tracking-wider block">
                  Corridor Spotlight
                </span>
                <h4 className="text-base font-bold text-white mt-0.5">{activeRate.lane}</h4>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Standard Equipment: {activeRate.equipment} · Distance: {activeRate.miles} Miles
                </div>
              </div>

              <div className="text-right font-mono">
                <div className="text-xl font-bold text-white">
                  {formatCurrency(activeRate.spotAverage)}
                </div>
                <div className="text-xs text-slate-400">
                  RPM: <span className="text-emerald-400 font-semibold">${activeRate.rpm}/mi</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-800 text-center font-mono">
              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <span className="text-[11px] text-slate-400 block">7-Day Rate Trend</span>
                <span
                  className={`text-sm font-bold mt-1 block ${
                    activeRate.weekChangePct >= 0 ? 'text-emerald-400' : 'text-blue-400'
                  }`}
                >
                  {activeRate.weekChangePct > 0 ? `+${activeRate.weekChangePct}%` : `${activeRate.weekChangePct}%`}
                </span>
                <span className="text-[10px] text-slate-500">Spot moving avg</span>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Capacity Ratio</span>
                <span className="text-sm font-bold text-white mt-1 block">
                  {activeRate.capacityRatio}
                </span>
                <span className="text-[10px] text-slate-500">Outbound density</span>
              </div>

              <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Tender Rejection</span>
                <span className="text-sm font-bold text-amber-400 mt-1 block">
                  {activeRate.tenderRejectionRate}%
                </span>
                <span className="text-[10px] text-slate-500">Contract carrier rejection</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-900/60 border border-slate-800/80 rounded-lg text-xs leading-relaxed text-slate-300">
              <strong className="text-white font-mono uppercase text-[11px] block mb-1">
                Brokerage Pricing Guidance:
              </strong>
              {activeRate.tenderRejectionRate > 6
                ? 'High rejection rate indicates tightening regional capacity. Increase target buy rates by $50-$100 and prioritize vetted carrier commitments early in the day.'
                : 'Looser regional capacity currently favors the broker. Offer counterbids at or below the 7-day moving average to optimize gross margins.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
