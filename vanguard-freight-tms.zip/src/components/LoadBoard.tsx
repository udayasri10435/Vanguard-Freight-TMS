import React, { useState } from 'react';
import { Load, EquipmentType, Carrier } from '../types/freight';
import {
  formatCurrency,
  formatNumber,
  estimateHighwayMiles,
  estimateBenchmarkRate,
  calculateMargin,
  calculateRPM,
} from '../utils/freightCalculators';
import {
  Truck,
  Plus,
  Search,
  Filter,
  ArrowRight,
  Share2,
  CheckCircle2,
  Clock,
  MapPin,
  FileCheck,
  AlertTriangle,
  ChevronRight,
  Thermometer,
  Shield,
  Layers,
  X,
  ExternalLink,
} from 'lucide-react';

interface LoadBoardProps {
  loads: Load[];
  carriers: Carrier[];
  onAddLoad: (newLoad: Load) => void;
  onUpdateLoad: (updated: Load) => void;
  onNavigateToNegotiation: (loadId: string) => void;
  onOpenRateConModal: (load: Load, carrier?: Carrier) => void;
}

export const LoadBoard: React.FC<LoadBoardProps> = ({
  loads,
  carriers,
  onAddLoad,
  onUpdateLoad,
  onNavigateToNegotiation,
  onOpenRateConModal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [equipmentFilter, setEquipmentFilter] = useState<string>('ALL');
  const [selectedLoad, setSelectedLoad] = useState<Load | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // New Load Form State
  const [newOriginCity, setNewOriginCity] = useState('Chicago');
  const [newOriginState, setNewOriginState] = useState('IL');
  const [newOriginZip, setNewOriginZip] = useState('60601');
  const [newOriginFacility, setNewOriginFacility] = useState('Midwest Gateway Logistics');
  const [newDestCity, setNewDestCity] = useState('Atlanta');
  const [newDestState, setNewDestState] = useState('GA');
  const [newDestZip, setNewDestZip] = useState('30303');
  const [newDestFacility, setNewDestFacility] = useState('Peachtree Distribution Terminal');
  const [newEquipment, setNewEquipment] = useState<EquipmentType>('Dry Van 53\'');
  const [newWeight, setNewWeight] = useState(42000);
  const [newCommodity, setNewCommodity] = useState('Consumer Packaged Goods');
  const [newShipperRate, setNewShipperRate] = useState(2900);
  const [newCarrierTarget, setNewCarrierTarget] = useState(2400);
  const [newShipperName, setNewShipperName] = useState('Allied Consumer Brands Inc');
  const [newTempReq, setNewTempReq] = useState('34°F Continuous');
  const [syndicateDAT, setSyndicateDAT] = useState(true);
  const [syndicateTruckstop, setSyndicateTruckstop] = useState(true);
  const [syndicateFleet, setSyndicateFleet] = useState(true);

  // Estimated miles for the new load modal
  const computedMiles = estimateHighwayMiles(
    `${newOriginCity}, ${newOriginState}`,
    `${newDestCity}, ${newDestState}`
  );
  const benchmarkRate = estimateBenchmarkRate(computedMiles, newEquipment);
  const computedMargin = calculateMargin(newShipperRate, newCarrierTarget);

  // Filter loads
  const filteredLoads = loads.filter((ld) => {
    const matchesSearch =
      ld.loadNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ld.origin.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ld.destination.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ld.shipperName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ld.commodity.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ld.assignedCarrierName && ld.assignedCarrierName.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === 'ALL' ||
      (statusFilter === 'OPEN' && (ld.status === 'OPEN' || ld.status === 'BIDDING')) ||
      (statusFilter === 'ACTIVE' && (ld.status === 'DISPATCHED' || ld.status === 'IN_TRANSIT')) ||
      (statusFilter === 'DELIVERED' && ld.status === 'DELIVERED') ||
      (statusFilter === 'SETTLED' && ld.status === 'SETTLED');

    const matchesEquipment =
      equipmentFilter === 'ALL' || ld.equipment.toLowerCase().includes(equipmentFilter.toLowerCase());

    return matchesSearch && matchesStatus && matchesEquipment;
  });

  const handleToggleBoardSyndication = (
    load: Load,
    board: 'DAT One' | 'Truckstop.com' | 'Direct Fleet'
  ) => {
    const exists = load.syndicatedBoards.includes(board);
    const updatedBoards = exists
      ? load.syndicatedBoards.filter((b) => b !== board)
      : [...load.syndicatedBoards, board];

    const updated: Load = {
      ...load,
      syndicatedBoards: updatedBoards,
    };
    onUpdateLoad(updated);
    if (selectedLoad?.id === load.id) {
      setSelectedLoad(updated);
    }
  };

  const handleCreateLoadSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const boards: ('DAT One' | 'Truckstop.com' | 'Direct Fleet')[] = [];
    if (syndicateDAT) boards.push('DAT One');
    if (syndicateTruckstop) boards.push('Truckstop.com');
    if (syndicateFleet) boards.push('Direct Fleet');

    const newLoad: Load = {
      id: `ld-${Date.now()}`,
      loadNumber: `VG-${Math.floor(8906 + Math.random() * 900)}`,
      shipperName: newShipperName,
      origin: {
        city: newOriginCity,
        state: newOriginState,
        zip: newOriginZip,
        facilityName: newOriginFacility,
        appointmentTime: 'Tomorrow 08:00',
        contactPhone: '(555) 019-4421',
        notes: 'Standard dock check-in required.',
      },
      destination: {
        city: newDestCity,
        state: newDestState,
        zip: newDestZip,
        facilityName: newDestFacility,
        appointmentTime: 'Day After Tomorrow 14:00',
        contactPhone: '(555) 991-8842',
        notes: 'Strict appointment time. Guard check on arrival.',
      },
      miles: computedMiles,
      equipment: newEquipment,
      weightLbs: newWeight,
      palletCount: 24,
      commodity: newCommodity,
      tempRequirement: newEquipment.includes('Reefer') ? newTempReq : undefined,
      shipperRate: newShipperRate,
      targetCarrierRate: newCarrierTarget,
      maxCarrierRate: newCarrierTarget + 150,
      status: 'OPEN',
      syndicatedBoards: boards,
      pickupDate: new Date().toISOString().split('T')[0],
      deliveryDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
      tracking: {
        currentMilestone: 'Broadcasted to Load Boards (DAT / Truckstop)',
        progressPct: 0,
        eta: 'In Scheduling',
        lastCheckCall: 'Automated post syndication live',
        notes: 'Awaiting compliant carrier counterbids.',
      },
      createdAt: 'Just now',
    };

    onAddLoad(newLoad);
    setIsCreateModalOpen(false);
    setSelectedLoad(newLoad);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Fast Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 bg-slate-900 border border-slate-800 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">
              Unified Load Board & Dispatch Center
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Tired of fragmented load posting across siloed portals. Publish once to syndicate
            simultaneously across DAT One, Truckstop.com, and Private Carrier Fleets.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Post New Load to Boards</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search load #, lane, shipper, commodity, carrier..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-slate-700"
          />
        </div>

        {/* Status Filters */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg overflow-x-auto">
          {[
            { id: 'ALL', label: 'All Loads' },
            { id: 'OPEN', label: 'Open / Bidding' },
            { id: 'ACTIVE', label: 'Dispatched & Rolling' },
            { id: 'DELIVERED', label: 'Delivered' },
            { id: 'SETTLED', label: 'Settled' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`py-1.5 px-3 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                statusFilter === tab.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Equipment Filter */}
        <select
          value={equipmentFilter}
          onChange={(e) => setEquipmentFilter(e.target.value)}
          className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white focus:outline-none shrink-0"
        >
          <option value="ALL">All Equipment</option>
          <option value="Dry Van">Dry Van 53'</option>
          <option value="Reefer">Reefer 53'</option>
          <option value="Flatbed">Flatbed 48'</option>
        </select>
      </div>

      {/* High-Density Data Grid of Loads */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 font-mono text-[11px] text-slate-400 uppercase tracking-wider">
                <th className="p-3">Load # / Shipper</th>
                <th className="p-3">Lane & Route</th>
                <th className="p-3">Equipment / Weight</th>
                <th className="p-3 text-right">Customer / Carrier</th>
                <th className="p-3 text-right">Est. Margin</th>
                <th className="p-3">Syndicated Boards</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans text-xs">
              {filteredLoads.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-500 text-xs">
                    No loads found matching filter criteria.
                  </td>
                </tr>
              ) : (
                filteredLoads.map((load) => {
                  const margin = calculateMargin(
                    load.shipperRate,
                    load.currentCarrierRate || load.targetCarrierRate
                  );

                  return (
                    <tr
                      key={load.id}
                      onClick={() => setSelectedLoad(load)}
                      className="hover:bg-slate-850/60 cursor-pointer transition-colors"
                    >
                      {/* Load Number & Shipper */}
                      <td className="p-3">
                        <div className="font-bold text-white font-mono">{load.loadNumber}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[140px]">
                          {load.shipperName}
                        </div>
                      </td>

                      {/* Lane & Route */}
                      <td className="p-3">
                        <div className="font-semibold text-slate-200 flex items-center gap-1.5 font-mono">
                          <span>
                            {load.origin.city}, {load.origin.state}
                          </span>
                          <ArrowRight className="w-3 h-3 text-slate-500" />
                          <span>
                            {load.destination.city}, {load.destination.state}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {load.miles} mi · Pick: {load.origin.appointmentTime.split(' ')[0]}
                        </div>
                      </td>

                      {/* Equipment & Commodity */}
                      <td className="p-3">
                        <div className="font-medium text-slate-300">{load.equipment}</div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[150px]">
                          {formatNumber(load.weightLbs)} lbs · {load.commodity}
                        </div>
                      </td>

                      {/* Financials */}
                      <td className="p-3 text-right font-mono">
                        <div className="text-white font-bold">
                          {formatCurrency(load.shipperRate)}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          Pay: {formatCurrency(load.currentCarrierRate || load.targetCarrierRate)}
                        </div>
                      </td>

                      {/* Margin */}
                      <td className="p-3 text-right font-mono">
                        <div
                          className={`font-semibold ${
                            margin.status === 'healthy'
                              ? 'text-emerald-400'
                              : margin.status === 'moderate'
                              ? 'text-amber-400'
                              : 'text-red-400'
                          }`}
                        >
                          {formatCurrency(margin.marginDollars)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {margin.marginPct.toFixed(1)}% yield
                        </div>
                      </td>

                      {/* Syndicated Boards */}
                      <td className="p-3">
                        <div className="flex items-center gap-1">
                          {['DAT One', 'Truckstop.com', 'Direct Fleet'].map((board) => {
                            const active = load.syndicatedBoards.includes(board as any);
                            return (
                              <button
                                key={board}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleBoardSyndication(load, board as any);
                                }}
                                title={`${board} ${active ? 'Live' : 'Inactive'}`}
                                className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition-colors ${
                                  active
                                    ? 'bg-blue-950 text-blue-300 border border-blue-800'
                                    : 'bg-slate-950 text-slate-600 border border-slate-800 hover:text-slate-400'
                                }`}
                              >
                                {board === 'DAT One' ? 'DAT' : board === 'Truckstop.com' ? 'TSTP' : 'FLEET'}
                              </button>
                            );
                          })}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="p-3">
                        <span
                          className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded font-semibold ${
                            load.status === 'OPEN'
                              ? 'bg-blue-950 text-blue-300 border border-blue-800'
                              : load.status === 'BIDDING'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : load.status === 'IN_TRANSIT'
                              ? 'bg-purple-950 text-purple-300 border border-purple-800'
                              : load.status === 'DELIVERED'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {load.status.replace(/_/g, ' ')}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-3 text-right">
                        <div
                          className="flex items-center justify-end gap-1.5"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {load.status === 'BIDDING' || load.status === 'OPEN' ? (
                            <button
                              onClick={() => onNavigateToNegotiation(load.id)}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded text-[11px] font-semibold transition-colors whitespace-nowrap"
                            >
                              Negotiate Rate
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                const carrier = carriers.find((c) => c.id === load.assignedCarrierId);
                                onOpenRateConModal(load, carrier);
                              }}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded text-[11px] font-medium transition-colors whitespace-nowrap"
                            >
                              Rate Con
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Load Quick Drawer / Modal */}
      {selectedLoad && (
        <div className="p-6 bg-slate-900 border border-blue-500/40 rounded-xl shadow-xl space-y-5">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 border-b border-slate-800 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold font-mono text-blue-400">
                  {selectedLoad.loadNumber}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Created {selectedLoad.createdAt}
                </span>
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">
                {selectedLoad.origin.city}, {selectedLoad.origin.state} →{' '}
                {selectedLoad.destination.city}, {selectedLoad.destination.state} ({selectedLoad.miles} Miles)
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const c = carriers.find((car) => car.id === selectedLoad.assignedCarrierId);
                  onOpenRateConModal(selectedLoad, c);
                }}
                className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700"
              >
                <FileCheck className="w-3.5 h-3.5" />
                <span>Rate Confirmation</span>
              </button>
              <button
                onClick={() => setSelectedLoad(null)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* Origin */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="font-bold text-blue-400 font-mono text-[11px] uppercase">
                Stop 1 · Origin Shipper
              </div>
              <div className="font-semibold text-white">{selectedLoad.origin.facilityName}</div>
              <div className="text-slate-400 font-mono">
                {selectedLoad.origin.city}, {selectedLoad.origin.state} {selectedLoad.origin.zip}
              </div>
              <div className="text-slate-300 font-mono pt-1">
                Appt: {selectedLoad.origin.appointmentTime}
              </div>
              <div className="text-slate-400">Tel: {selectedLoad.origin.contactPhone}</div>
            </div>

            {/* Destination */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="font-bold text-emerald-400 font-mono text-[11px] uppercase">
                Stop 2 · Destination Receiver
              </div>
              <div className="font-semibold text-white">{selectedLoad.destination.facilityName}</div>
              <div className="text-slate-400 font-mono">
                {selectedLoad.destination.city}, {selectedLoad.destination.state} {selectedLoad.destination.zip}
              </div>
              <div className="text-slate-300 font-mono pt-1">
                Appt: {selectedLoad.destination.appointmentTime}
              </div>
              <div className="text-slate-400">Tel: {selectedLoad.destination.contactPhone}</div>
            </div>

            {/* Assigned Carrier & Tracking */}
            <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-lg space-y-1">
              <div className="font-bold text-slate-300 font-mono text-[11px] uppercase">
                Dispatch & Tracking Status
              </div>
              <div className="font-semibold text-white">
                {selectedLoad.assignedCarrierName ? (
                  <span>{selectedLoad.assignedCarrierName}</span>
                ) : (
                  <span className="text-amber-400">Unassigned (Open on Load Boards)</span>
                )}
              </div>
              {selectedLoad.assignedCarrierMc && (
                <div className="text-slate-400 font-mono">
                  MC#: {selectedLoad.assignedCarrierMc} · Driver: {selectedLoad.driverName || 'TBD'}
                </div>
              )}
              <div className="text-slate-300 font-mono pt-1">
                Milestone: {selectedLoad.tracking.currentMilestone}
              </div>
              {selectedLoad.tracking.temperatureActual && (
                <div className="text-blue-400 font-mono flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5" />
                  <span>Reefer Sensor: {selectedLoad.tracking.temperatureActual}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Post New Load Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-xl shadow-2xl p-6 my-8 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-400" />
                <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wide">
                  Post New Freight Shipment & Syndicate
                </h3>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLoadSubmit} className="space-y-4 text-xs">
              {/* Shipper & Commodity */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-mono block mb-1">Customer / Shipper:</label>
                  <input
                    type="text"
                    required
                    value={newShipperName}
                    onChange={(e) => setNewShipperName(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-mono block mb-1">Commodity:</label>
                  <input
                    type="text"
                    required
                    value={newCommodity}
                    onChange={(e) => setNewCommodity(e.target.value)}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Origin */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
                <div className="font-bold text-blue-400 font-mono text-[11px] uppercase">
                  Origin (Pickup)
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="City"
                    value={newOriginCity}
                    onChange={(e) => setNewOriginCity(e.target.value)}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white"
                    required
                  />
                  <input
                    type="text"
                    placeholder="State"
                    value={newOriginState}
                    onChange={(e) => setNewOriginState(e.target.value.toUpperCase())}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white font-mono"
                    maxLength={2}
                    required
                  />
                  <input
                    type="text"
                    placeholder="Facility Name"
                    value={newOriginFacility}
                    onChange={(e) => setNewOriginFacility(e.target.value)}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white"
                  />
                </div>
              </div>

              {/* Destination */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
                <div className="font-bold text-emerald-400 font-mono text-[11px] uppercase">
                  Destination (Delivery)
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="City"
                    value={newDestCity}
                    onChange={(e) => setNewDestCity(e.target.value)}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white"
                    required
                  />
                  <input
                    type="text"
                    placeholder="State"
                    value={newDestState}
                    onChange={(e) => setNewDestState(e.target.value.toUpperCase())}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white font-mono"
                    maxLength={2}
                    required
                  />
                  <input
                    type="text"
                    placeholder="Facility Name"
                    value={newDestFacility}
                    onChange={(e) => setNewDestFacility(e.target.value)}
                    className="p-2 bg-slate-900 border border-slate-700 rounded text-white"
                  />
                </div>
              </div>

              {/* Equipment & Specs */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 font-mono block mb-1">Equipment:</label>
                  <select
                    value={newEquipment}
                    onChange={(e) => setNewEquipment(e.target.value as any)}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded text-white"
                  >
                    <option value="Dry Van 53'">Dry Van 53'</option>
                    <option value="Reefer 53'">Reefer 53'</option>
                    <option value="Flatbed 48'">Flatbed 48'</option>
                    <option value="Step Deck">Step Deck</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 font-mono block mb-1">Weight (Lbs):</label>
                  <input
                    type="number"
                    value={newWeight}
                    onChange={(e) => setNewWeight(Number(e.target.value))}
                    className="w-full p-2 bg-slate-950 border border-slate-700 rounded text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-mono block mb-1">Calculated Miles:</label>
                  <div className="p-2 bg-slate-950 border border-slate-800 rounded font-mono text-white font-bold">
                    {computedMiles} Miles
                  </div>
                </div>
              </div>

              {/* Rates & Margin Preview */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg space-y-2">
                <div className="flex justify-between items-center text-[11px] font-mono">
                  <span className="text-slate-400">DAT Lane Spot Benchmark:</span>
                  <span className="text-blue-400 font-bold">{formatCurrency(benchmarkRate)}</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 font-mono block mb-1">
                      Shipper Quote ($ Customer Pays):
                    </label>
                    <input
                      type="number"
                      value={newShipperRate}
                      onChange={(e) => setNewShipperRate(Number(e.target.value))}
                      className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-white font-mono font-bold"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 font-mono block mb-1">
                      Target Carrier Pay ($ Buy Rate):
                    </label>
                    <input
                      type="number"
                      value={newCarrierTarget}
                      onChange={(e) => setNewCarrierTarget(Number(e.target.value))}
                      className="w-full p-2 bg-slate-900 border border-slate-700 rounded text-white font-mono font-bold"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-xs font-mono">
                  <span className="text-slate-300">Projected Gross Margin:</span>
                  <span
                    className={`font-bold ${
                      computedMargin.status === 'healthy'
                        ? 'text-emerald-400'
                        : computedMargin.status === 'moderate'
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {formatCurrency(computedMargin.marginDollars)} ({computedMargin.marginPct.toFixed(1)}%)
                  </span>
                </div>
              </div>

              {/* 1-Click Multi-Board Syndication */}
              <div>
                <label className="text-slate-400 font-mono block mb-1.5">
                  Simultaneous Load Board Syndication:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={syndicateDAT}
                      onChange={(e) => setSyndicateDAT(e.target.checked)}
                      className="rounded text-blue-600 bg-slate-900 border-slate-700"
                    />
                    <span className="text-slate-200 font-mono text-[11px]">DAT One</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={syndicateTruckstop}
                      onChange={(e) => setSyndicateTruckstop(e.target.checked)}
                      className="rounded text-blue-600 bg-slate-900 border-slate-700"
                    />
                    <span className="text-slate-200 font-mono text-[11px]">Truckstop.com</span>
                  </label>

                  <label className="flex items-center gap-2 p-2 bg-slate-950 border border-slate-800 rounded cursor-pointer">
                    <input
                      type="checkbox"
                      checked={syndicateFleet}
                      onChange={(e) => setSyndicateFleet(e.target.checked)}
                      className="rounded text-blue-600 bg-slate-900 border-slate-700"
                    />
                    <span className="text-slate-200 font-mono text-[11px]">Direct Fleet</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3 py-1.5 text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg shadow-sm"
                >
                  Post & Syndicate Load
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
