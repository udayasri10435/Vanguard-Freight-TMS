import React, { useState } from 'react';
import { Carrier, ComplianceTier, RiskLevel } from '../types/freight';
import {
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Building2,
  FileCheck2,
  Search,
  ExternalLink,
  Plus,
  RefreshCw,
  Phone,
  Mail,
  Truck,
  CheckCircle,
  XCircle,
  Lock,
  ChevronRight,
} from 'lucide-react';
import { formatCurrency } from '../utils/freightCalculators';

interface CarrierVettingProps {
  carriers: Carrier[];
  onUpdateCarrier: (updated: Carrier) => void;
  onAddCarrier: (newCarrier: Carrier) => void;
}

export const CarrierVetting: React.FC<CarrierVettingProps> = ({
  carriers,
  onUpdateCarrier,
  onAddCarrier,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('ALL');
  const [selectedCarrier, setSelectedCarrier] = useState<Carrier>(carriers[0]);
  const [isVerifyingNew, setIsVerifyingNew] = useState(false);
  const [lookupMc, setLookupMc] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [overrideModalOpen, setOverrideModalOpen] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');
  const [supervisorPin, setSupervisorPin] = useState('');
  const [overrideError, setOverrideError] = useState('');

  // Filter carriers
  const filteredCarriers = carriers.filter((c) => {
    const matchesSearch =
      c.legalName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.mcNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.dotNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.homeTerminal.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesTier =
      tierFilter === 'ALL' ||
      (tierFilter === 'APPROVED' &&
        (c.complianceTier === 'APPROVED_PREMIER' || c.complianceTier === 'STANDARD_APPROVED')) ||
      (tierFilter === 'FLAGGED' && c.complianceTier === 'REQUIRES_SUPERVISOR_OVERRIDE') ||
      (tierFilter === 'DNU' && c.complianceTier === 'DO_NOT_USE_DNU');

    return matchesSearch && matchesTier;
  });

  // Simulated FMCSA live lookup for new MC#
  const handleRunFmcsaLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lookupMc.trim()) return;

    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      // Generate a mock evaluated carrier based on input
      const cleanMc = lookupMc.toUpperCase().startsWith('MC-') ? lookupMc.toUpperCase() : `MC-${lookupMc}`;
      const isSuspect = cleanMc.includes('99') || cleanMc.includes('13') || cleanMc.endsWith('7');

      const newCarrier: Carrier = {
        id: `carr-${Date.now()}`,
        mcNumber: cleanMc,
        dotNumber: `USDOT-${Math.floor(3000000 + Math.random() * 900000)}`,
        legalName: isSuspect ? `${lookupMc} Freight Logistics Inc` : `${lookupMc} Carrier Group LLC`,
        contactName: isSuspect ? 'Dmitri Kozlov' : 'James Bradley',
        phone: '(555) ' + Math.floor(100 + Math.random() * 900) + '-' + Math.floor(1000 + Math.random() * 9000),
        email: isSuspect ? 'dispatch.expresshaul@yahoo.com' : `ops@${lookupMc.toLowerCase().replace(/[^a-z0-9]/g, '')}freight.com`,
        homeTerminal: isSuspect ? 'Sherman Oaks, CA' : 'Columbus, OH',
        authorityAgeYears: isSuspect ? 0.2 : 4.5,
        fmcsaStatus: 'AUTHORIZED',
        safetyRating: isSuspect ? 'UNRATED' : 'SATISFACTORY',
        oosDriverRate: isSuspect ? 0.0 : 3.8,
        oosVehicleRate: isSuspect ? 0.0 : 16.5,
        insurance: {
          autoLiability: 1000000,
          cargoLiability: isSuspect ? 100000 : 250000,
          expiresAt: '2027-08-30',
          policyNumber: `POL-${Math.floor(100000 + Math.random() * 900000)}`,
          underwriter: isSuspect ? 'Surplus Lines Underwriters Ltd' : 'Nationwide Mutual Insurance',
          coiVerified: !isSuspect,
        },
        fraudAudit: {
          score: isSuspect ? 42 : 94,
          riskLevel: isSuspect ? 'CRITICAL' : 'LOW',
          doubleBrokerAlert: isSuspect,
          chameleonScore: isSuspect ? 79 : 6,
          addressFlag: isSuspect,
          phoneDomainMismatch: isSuspect,
          fraudFlags: isSuspect
            ? [
                'CRITICAL: Commercial mailbox address registered with FMCSA',
                'HIGH: Chameleon score 79% (affiliated with revoked MC-812001)',
                'ALERT: Webmail address mismatch on enterprise filing',
              ]
            : ['Verified physical yard with active fleet', 'Clean 4.5 yr authority record', 'Zero fraud reports in TIA registry'],
        },
        complianceTier: isSuspect ? 'DO_NOT_USE_DNU' : 'STANDARD_APPROVED',
        fleetSize: isSuspect ? 1 : 12,
        preferredLanes: ['Midwest Regional'],
        totalLoadsCompleted: 0,
        onTimeDeliveryRate: 100.0,
      };

      onAddCarrier(newCarrier);
      setSelectedCarrier(newCarrier);
      setLookupMc('');
      setIsVerifyingNew(false);
    }, 900);
  };

  const handleSupervisorOverrideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (supervisorPin !== '7744') {
      setOverrideError('Invalid Supervisor Authorization PIN (Hint: demo PIN is 7744)');
      return;
    }
    if (!overrideReason.trim()) {
      setOverrideError('Formal override justification is required for audit logs.');
      return;
    }

    const updated: Carrier = {
      ...selectedCarrier,
      complianceTier: 'STANDARD_APPROVED',
      fraudAudit: {
        ...selectedCarrier.fraudAudit,
        fraudFlags: [
          ...selectedCarrier.fraudAudit.fraudFlags,
          `SUPERVISOR OVERRIDE APPROVED: ${overrideReason} (By Safety Director · PIN #7744)`,
        ],
      },
    };

    onUpdateCarrier(updated);
    setSelectedCarrier(updated);
    setOverrideModalOpen(false);
    setOverrideReason('');
    setSupervisorPin('');
    setOverrideError('');
  };

  const handleToggleDNU = () => {
    const isDnu = selectedCarrier.complianceTier === 'DO_NOT_USE_DNU';
    const updated: Carrier = {
      ...selectedCarrier,
      complianceTier: isDnu ? 'STANDARD_APPROVED' : 'DO_NOT_USE_DNU',
    };
    onUpdateCarrier(updated);
    setSelectedCarrier(updated);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Framing */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 bg-slate-900/80 border border-slate-800 rounded-xl">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">
              Carrier Vetting & Fraud Shield
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Eliminate double-brokering scams, chameleon carriers, and lapsed insurance certificates.
            Synchronized with FMCSA SAFER, TIA Watchdog, and automated physical address registries.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsVerifyingNew(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Instant FMCSA Lookup</span>
          </button>
        </div>
      </div>

      {/* New Carrier Lookup Form Drawer/Bar */}
      {isVerifyingNew && (
        <form
          onSubmit={handleRunFmcsaLookup}
          className="p-5 bg-slate-900 border border-blue-500/40 rounded-xl shadow-lg space-y-3"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 text-blue-400 ${isScanning ? 'animate-spin' : ''}`} />
              <span className="text-xs font-bold text-white tracking-wider uppercase font-mono">
                Live FMCSA & SAFER Registry Lookup
              </span>
            </div>
            <button
              type="button"
              onClick={() => setIsVerifyingNew(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Enter MC Number (e.g. MC-789012 or 789012)..."
                value={lookupMc}
                onChange={(e) => setLookupMc(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
                required
              />
            </div>
            <button
              type="submit"
              disabled={isScanning}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 shrink-0"
            >
              {isScanning ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Scanning FMCSA SAFER & TIA Fraud Database...</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>Run Fraud & Safety Scan</span>
                </>
              )}
            </button>
          </div>
          <p className="text-[11px] text-slate-400">
            Scanning runs automatic cross-checks against 18 risk vectors: Operating Authority status, TIA double-broker flags, commercial address verification, and COI policy validity.
          </p>
        </form>
      )}

      {/* Main Grid: Left Carrier List + Right Deep Vetting Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Carrier Roster & Filter */}
        <div className="lg:col-span-5 space-y-4">
          {/* Search & Filter */}
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                placeholder="Search MC#, DOT#, or Carrier Name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-slate-700"
              />
            </div>

            {/* Segmented Tier Controls */}
            <div className="flex items-center gap-1 p-1 bg-slate-900/90 border border-slate-800 rounded-lg">
              {[
                { id: 'ALL', label: 'All Carriers' },
                { id: 'APPROVED', label: 'Approved' },
                { id: 'FLAGGED', label: 'Action Required' },
                { id: 'DNU', label: 'DNU / Blacklist' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setTierFilter(tab.id)}
                  className={`flex-1 py-1.5 px-2 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                    tierFilter === tab.id
                      ? 'bg-slate-800 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Roster Cards */}
          <div className="space-y-2 max-h-[680px] overflow-y-auto pr-1">
            {filteredCarriers.length === 0 ? (
              <div className="p-8 text-center bg-slate-900/40 border border-slate-800/80 rounded-xl text-xs text-slate-400">
                No carriers found matching criteria.
              </div>
            ) : (
              filteredCarriers.map((c) => {
                const isSelected = selectedCarrier.id === c.id;
                const isDNU = c.complianceTier === 'DO_NOT_USE_DNU';
                const isWarning = c.complianceTier === 'REQUIRES_SUPERVISOR_OVERRIDE';
                const isPremier = c.complianceTier === 'APPROVED_PREMIER';

                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedCarrier(c)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-blue-500/80 shadow-md ring-1 ring-blue-500/20'
                        : 'bg-slate-900/70 border-slate-800/80 hover:bg-slate-850 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-xs text-white leading-tight">
                          {c.legalName}
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono mt-0.5">
                          <span>{c.mcNumber}</span>
                          <span aria-hidden="true">·</span>
                          <span>{c.dotNumber}</span>
                        </div>
                      </div>

                      {/* Compliance Status Chip / Indicator */}
                      <div className="shrink-0 text-right">
                        {isDNU ? (
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-red-950/80 text-red-400 border border-red-800/60 font-medium">
                            DNU Blacklisted
                          </span>
                        ) : isWarning ? (
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-950/80 text-amber-400 border border-amber-800/60 font-medium">
                            Override Req
                          </span>
                        ) : isPremier ? (
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 font-medium">
                            Premier Approved
                          </span>
                        ) : (
                          <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800/60 font-medium">
                            Standard
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2.5 pt-2 border-t border-slate-800/60 font-mono">
                      <span>{c.homeTerminal}</span>
                      <div className="flex items-center gap-2">
                        <span>{c.fleetSize} Power Units</span>
                        <span aria-hidden="true">·</span>
                        <span
                          className={
                            c.fraudAudit.score < 60
                              ? 'text-red-400 font-bold'
                              : 'text-emerald-400 font-medium'
                          }
                        >
                          Score {c.fraudAudit.score}/100
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Deep Carrier Vetting Dossier */}
        <div className="lg:col-span-7">
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-6">
            {/* Dossier Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-slate-800 gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white">
                    {selectedCarrier.legalName}
                  </h3>
                  {selectedCarrier.dbaName && (
                    <span className="text-xs text-slate-400 font-normal">
                      (DBA: {selectedCarrier.dbaName})
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono mt-1">
                  <span className="text-blue-400">{selectedCarrier.mcNumber}</span>
                  <span aria-hidden="true">·</span>
                  <span>{selectedCarrier.dotNumber}</span>
                  <span aria-hidden="true">·</span>
                  <span>Home: {selectedCarrier.homeTerminal}</span>
                  <span aria-hidden="true">·</span>
                  <span>Authority: {selectedCarrier.authorityAgeYears} Years Active</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                {selectedCarrier.complianceTier === 'REQUIRES_SUPERVISOR_OVERRIDE' && (
                  <button
                    onClick={() => setOverrideModalOpen(true)}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Supervisor Override</span>
                  </button>
                )}
                <button
                  onClick={handleToggleDNU}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    selectedCarrier.complianceTier === 'DO_NOT_USE_DNU'
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      : 'bg-red-950/80 hover:bg-red-900 text-red-300 border border-red-800/80'
                  }`}
                >
                  {selectedCarrier.complianceTier === 'DO_NOT_USE_DNU' ? (
                    <>
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Re-Instate Carrier</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Place on DNU / Blacklist</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Critical Fraud & Double-Broker Shield Card */}
            <div
              className={`p-4 rounded-xl border ${
                selectedCarrier.fraudAudit.riskLevel === 'CRITICAL' ||
                selectedCarrier.fraudAudit.doubleBrokerAlert
                  ? 'bg-red-950/40 border-red-800/80'
                  : selectedCarrier.fraudAudit.riskLevel === 'MEDIUM'
                  ? 'bg-amber-950/30 border-amber-800/80'
                  : 'bg-slate-950/60 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  {selectedCarrier.fraudAudit.riskLevel === 'CRITICAL' ? (
                    <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
                  ) : selectedCarrier.fraudAudit.riskLevel === 'MEDIUM' ? (
                    <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  <div>
                    <div className="text-xs font-bold text-white tracking-wider uppercase font-mono">
                      TIA Fraud & Double-Brokering Shield Audit
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Risk Level: <span className="font-semibold text-white uppercase">{selectedCarrier.fraudAudit.riskLevel}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-lg font-bold font-mono text-white">
                    {selectedCarrier.fraudAudit.score}
                    <span className="text-xs text-slate-400 font-normal">/100</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">Integrity Score</div>
                </div>
              </div>

              {/* Fraud Flags Breakdown */}
              <div className="space-y-1.5">
                {selectedCarrier.fraudAudit.fraudFlags.map((flag, idx) => (
                  <div
                    key={idx}
                    className={`text-xs flex items-start gap-2 p-2 rounded ${
                      flag.startsWith('CRITICAL') || flag.startsWith('HIGH')
                        ? 'bg-red-900/30 text-red-200 border border-red-800/50'
                        : flag.startsWith('WARNING') || flag.startsWith('SUPERVISOR')
                        ? 'bg-amber-900/30 text-amber-200 border border-amber-800/50'
                        : 'bg-slate-800/50 text-slate-300'
                    }`}
                  >
                    <ChevronRight className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-400" />
                    <span>{flag}</span>
                  </div>
                ))}
              </div>

              {/* Fraud Vectors Details */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4 pt-3 border-t border-slate-800/60 font-mono text-xs">
                <div>
                  <span className="text-[11px] text-slate-400 block">Chameleon Similarity:</span>
                  <span
                    className={
                      selectedCarrier.fraudAudit.chameleonScore > 50
                        ? 'text-red-400 font-bold'
                        : 'text-emerald-400'
                    }
                  >
                    {selectedCarrier.fraudAudit.chameleonScore}% Match
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Address Audit:</span>
                  <span
                    className={
                      selectedCarrier.fraudAudit.addressFlag
                        ? 'text-red-400 font-bold'
                        : 'text-emerald-400'
                    }
                  >
                    {selectedCarrier.fraudAudit.addressFlag ? 'Flagged (Mailbox Drop)' : 'Commercial Yard'}
                  </span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Domain Check:</span>
                  <span
                    className={
                      selectedCarrier.fraudAudit.phoneDomainMismatch
                        ? 'text-red-400 font-bold'
                        : 'text-emerald-400'
                    }
                  >
                    {selectedCarrier.fraudAudit.phoneDomainMismatch ? 'Free Webmail Warning' : 'Corporate Verified'}
                  </span>
                </div>
              </div>
            </div>

            {/* FMCSA SAFER & Safety Performance Matrix */}
            <div>
              <div className="text-xs font-bold text-white tracking-wider uppercase font-mono mb-3">
                FMCSA SAFER Roadside Safety Audit
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div className="text-[11px] text-slate-400">FMCSA Operating Authority</div>
                  <div className="text-sm font-bold text-emerald-400 font-mono mt-1">
                    {selectedCarrier.fmcsaStatus}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">Active Common Property Authority</div>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div className="text-[11px] text-slate-400">Driver Out-of-Service (OOS)</div>
                  <div className="text-sm font-bold font-mono mt-1 text-white">
                    {selectedCarrier.oosDriverRate.toFixed(1)}%
                    <span className="text-[11px] text-slate-500 font-normal ml-1">
                      (Nat. Avg: 5.5%)
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {selectedCarrier.oosDriverRate <= 5.5 ? '✓ Below national hazard rate' : '⚠ Elevated inspection rate'}
                  </div>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div className="text-[11px] text-slate-400">Vehicle Out-of-Service (OOS)</div>
                  <div className="text-sm font-bold font-mono mt-1 text-white">
                    {selectedCarrier.oosVehicleRate.toFixed(1)}%
                    <span className="text-[11px] text-slate-500 font-normal ml-1">
                      (Nat. Avg: 21.4%)
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {selectedCarrier.oosVehicleRate <= 21.4 ? '✓ Within safety standards' : '⚠ Maintenance caution'}
                  </div>
                </div>
              </div>
            </div>

            {/* Certificate of Insurance (COI) Verification */}
            <div>
              <div className="text-xs font-bold text-white tracking-wider uppercase font-mono mb-3">
                Certificate of Insurance (COI) Verification
              </div>
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-slate-800">
                  <div>
                    <div className="text-xs font-semibold text-white">
                      Underwriter: {selectedCarrier.insurance.underwriter}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Policy #{selectedCarrier.insurance.policyNumber}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-400 font-mono">
                      Expiration: <span className="text-white font-medium">{selectedCarrier.insurance.expiresAt}</span>
                    </div>
                    <div className="text-[10px] text-emerald-400 font-medium mt-0.5">
                      {selectedCarrier.insurance.coiVerified ? '✓ Verified with insurer direct' : '⚠ Pending automated API re-check'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Auto Liability Coverage:</span>
                    <span className="text-white font-semibold text-sm">
                      {formatCurrency(selectedCarrier.insurance.autoLiability)}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {selectedCarrier.insurance.autoLiability >= 1000000 ? 'Meets $1.0M TIA standard' : 'Below $1.0M threshold'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-400 block">Cargo Liability Coverage:</span>
                    <span className="text-white font-semibold text-sm">
                      {formatCurrency(selectedCarrier.insurance.cargoLiability)}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {selectedCarrier.insurance.cargoLiability >= 100000 ? 'Sufficient for high-value freight' : 'Insufficient cargo bond'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Carrier Contact & Dispatch Metadata */}
            <div className="pt-2 border-t border-slate-800 text-xs text-slate-400 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span>Dispatch: {selectedCarrier.contactName} ({selectedCarrier.phone})</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span className="truncate">{selectedCarrier.email}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Supervisor Override Modal */}
      {overrideModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/50 rounded-xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-white uppercase font-mono tracking-wide">
                Safety Director Compliance Override
              </h3>
            </div>
            <p className="text-xs text-slate-300">
              You are authorizing an exception for{' '}
              <strong className="text-white">{selectedCarrier.legalName}</strong> ({selectedCarrier.mcNumber}).
              This action will be permanently recorded in the broker audit ledger.
            </p>

            <form onSubmit={handleSupervisorOverrideSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">
                  Formal Justification / Risk Mitigation:
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="e.g. Verified updated COI with underwriter directly via phone; driver is vetted company-employed driver."
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 block mb-1">
                  Safety Director Security PIN:
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter 4-digit PIN (demo: 7744)"
                  value={supervisorPin}
                  onChange={(e) => setSupervisorPin(e.target.value)}
                  className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 font-mono tracking-widest"
                />
              </div>

              {overrideError && (
                <div className="text-xs text-red-400 bg-red-950/60 p-2 rounded border border-red-800">
                  {overrideError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setOverrideModalOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold"
                >
                  Confirm & Authorize Load Dispatch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
