import React, { useState } from 'react';
import { SettlementRecord, AccessorialItem } from '../types/freight';
import { formatCurrency } from '../utils/freightCalculators';
import {
  FileText,
  CreditCard,
  Building,
  CheckCircle2,
  Clock,
  Plus,
  Send,
  Printer,
  ShieldCheck,
  AlertCircle,
  FileCheck,
  Zap,
} from 'lucide-react';

interface SettlementLedgerProps {
  settlements: SettlementRecord[];
  onUpdateSettlement: (updated: SettlementRecord) => void;
  onOpenDocument: (type: 'SETTLEMENT_VOUCHER' | 'SHIPPER_INVOICE', record: SettlementRecord) => void;
}

export const SettlementLedger: React.FC<SettlementLedgerProps> = ({
  settlements,
  onUpdateSettlement,
  onOpenDocument,
}) => {
  const [activeTab, setActiveTab] = useState<string>('ALL');
  const [selectedSettlementId, setSelectedSettlementId] = useState<string>(
    settlements[0]?.id || ''
  );
  const [showAddAccessorial, setShowAddAccessorial] = useState(false);
  const [newAccType, setNewAccType] = useState<AccessorialItem['type']>('DETENTION');
  const [newAccDesc, setNewAccDesc] = useState('');
  const [newAccAmount, setNewAccAmount] = useState<number>(75);
  const [newAccBillable, setNewAccBillable] = useState(true);

  const selectedSettlement =
    settlements.find((s) => s.id === selectedSettlementId) || settlements[0];

  const filteredSettlements = settlements.filter((s) => {
    if (activeTab === 'AWAITING_POD') return s.status === 'AWAITING_POD';
    if (activeTab === 'READY') return s.status === 'READY_FOR_PAYMENT';
    if (activeTab === 'PAID') return s.status === 'PAID_PROCESSED';
    return true;
  });

  // Aggregate stats
  const totalInvoiced = settlements.reduce((acc, s) => acc + s.shipperTotalInvoiced, 0);
  const totalCarrierPay = settlements.reduce((acc, s) => acc + s.carrierTotalEarned, 0);
  const totalNetMargin = settlements.reduce((acc, s) => acc + s.grossBrokerMargin, 0);
  const totalQuickPayVolume = settlements
    .filter((s) => s.quickPaySelected)
    .reduce((acc, s) => acc + s.finalCarrierPayout, 0);

  // Toggle QuickPay for the active settlement
  const handleToggleQuickPay = () => {
    if (!selectedSettlement) return;
    const newQuickPay = !selectedSettlement.quickPaySelected;
    const feePct = newQuickPay ? 2.0 : 0;
    const discount = (selectedSettlement.carrierTotalEarned * feePct) / 100;
    const finalPayout = selectedSettlement.carrierTotalEarned - discount;

    const updated: SettlementRecord = {
      ...selectedSettlement,
      quickPaySelected: newQuickPay,
      quickPayFeePct: feePct,
      quickPayDiscount: discount,
      finalCarrierPayout: finalPayout,
      paymentMethod: newQuickPay ? 'ACH_QUICKPAY_SAME_DAY' : 'STANDARD_NET_30',
    };

    onUpdateSettlement(updated);
  };

  // Add an accessorial
  const handleAddAccessorial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSettlement || newAccAmount <= 0) return;

    const newAcc: AccessorialItem = {
      id: `acc-${Date.now()}`,
      type: newAccType,
      description: newAccDesc.trim() || `${newAccType.replace(/_/g, ' ')} authorized charge`,
      amount: newAccAmount,
      billableToCustomer: newAccBillable,
      receiptVerified: true,
    };

    const newAccessorials = [...selectedSettlement.accessorials, newAcc];
    const newCarrierTotalEarned = selectedSettlement.carrierBasePay + newAccessorials.reduce((a, b) => a + b.amount, 0);
    const newShipperTotalInvoiced = newAccBillable
      ? selectedSettlement.shipperTotalInvoiced + newAccAmount
      : selectedSettlement.shipperTotalInvoiced;

    const discount = selectedSettlement.quickPaySelected
      ? (newCarrierTotalEarned * selectedSettlement.quickPayFeePct) / 100
      : 0;

    const updated: SettlementRecord = {
      ...selectedSettlement,
      accessorials: newAccessorials,
      carrierTotalEarned: newCarrierTotalEarned,
      shipperTotalInvoiced: newShipperTotalInvoiced,
      quickPayDiscount: discount,
      finalCarrierPayout: newCarrierTotalEarned - discount,
      grossBrokerMargin: newShipperTotalInvoiced - (newCarrierTotalEarned - discount),
      marginPct:
        ((newShipperTotalInvoiced - (newCarrierTotalEarned - discount)) /
          newShipperTotalInvoiced) *
        100,
    };

    onUpdateSettlement(updated);
    setShowAddAccessorial(false);
    setNewAccDesc('');
  };

  // Process disbursement
  const handleProcessDisbursement = () => {
    if (!selectedSettlement) return;
    const updated: SettlementRecord = {
      ...selectedSettlement,
      status: 'PAID_PROCESSED',
      podSigned: true,
      bolSigned: true,
      rateConSigned: true,
      paymentDueDate: new Date().toLocaleDateString('en-US'),
      notes: `ACH Disbursement initiated (${selectedSettlement.paymentMethod}) · Batch #${Math.floor(
        1000 + Math.random() * 9000
      )}. Remittance statement delivered.`,
    };
    onUpdateSettlement(updated);
  };

  return (
    <div className="space-y-6">
      {/* Top Ledger Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between p-5 bg-slate-900 border border-slate-800 rounded-xl gap-4">
        <div>
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">
              Settlement & Carrier Pay Ledger
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Streamlining fragmented freight settlements: automated BOL/POD audit, QuickPay 2% ACH
            accelerator, Factoring Notice of Assignment (NOA) management, and shipper invoicing.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onOpenDocument('SETTLEMENT_VOUCHER', selectedSettlement)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Remittance Voucher</span>
          </button>
          <button
            onClick={() => onOpenDocument('SHIPPER_INVOICE', selectedSettlement)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Shipper Invoice</span>
          </button>
        </div>
      </div>

      {/* Financial Health Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 font-mono">Shipper AR (Invoiced)</div>
          <div className="text-lg font-bold font-mono text-white mt-1">
            {formatCurrency(totalInvoiced)}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Across {settlements.length} freight shipments
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 font-mono">Carrier AP (Payables)</div>
          <div className="text-lg font-bold font-mono text-slate-200 mt-1">
            {formatCurrency(totalCarrierPay)}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-1">
            Standard Net 30 & QuickPay
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 font-mono">Brokerage Gross Margin</div>
          <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
            {formatCurrency(totalNetMargin)}
          </div>
          <div className="text-[11px] text-emerald-500/80 font-mono mt-1">
            {((totalNetMargin / totalInvoiced) * 100).toFixed(1)}% Gross Yield
          </div>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 font-mono">QuickPay 24h Funded</div>
          <div className="text-lg font-bold font-mono text-blue-400 mt-1">
            {formatCurrency(totalQuickPayVolume)}
          </div>
          <div className="text-[11px] text-blue-400/80 font-mono mt-1">
            2.0% ACH Fee Earned
          </div>
        </div>
      </div>

      {/* Main Grid: Left Settlements List + Right Settlement Auditor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Settlement Items List */}
        <div className="lg:col-span-5 space-y-3">
          {/* Segmented Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            {[
              { id: 'ALL', label: 'All Items' },
              { id: 'AWAITING_POD', label: 'Pending POD' },
              { id: 'READY', label: 'Ready to Pay' },
              { id: 'PAID', label: 'Paid & Closed' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-1.5 px-2 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* List of records */}
          <div className="space-y-2">
            {filteredSettlements.map((record) => {
              const isSelected = record.id === selectedSettlement.id;

              return (
                <div
                  key={record.id}
                  onClick={() => setSelectedSettlementId(record.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-blue-500 shadow-md ring-1 ring-blue-500/20'
                      : 'bg-slate-900/70 border-slate-800 hover:bg-slate-850 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold text-xs text-white">
                        {record.loadNumber} · {record.carrierName}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Shipper: {record.shipperName}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-bold font-mono text-white">
                        {formatCurrency(record.finalCarrierPayout)}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {record.quickPaySelected ? 'QuickPay (-2%)' : 'Net 30'}
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-slate-300 font-mono truncate">
                    {record.lane}
                  </div>

                  <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800 text-[11px] font-mono">
                    <span className="text-emerald-400">
                      Broker Margin: {formatCurrency(record.grossBrokerMargin)} (
                      {record.marginPct.toFixed(1)}%)
                    </span>

                    <span
                      className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded font-medium ${
                        record.status === 'PAID_PROCESSED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : record.status === 'READY_FOR_PAYMENT'
                          ? 'bg-blue-950 text-blue-300 border border-blue-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {record.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Detailed Settlement Auditor */}
        <div className="lg:col-span-7">
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-6">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold font-mono px-2 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded">
                    {selectedSettlement.loadNumber}
                  </span>
                  <h3 className="text-base font-bold text-white">
                    {selectedSettlement.carrierName}
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400 font-mono mt-1">
                  <span>{selectedSettlement.carrierMc}</span>
                  <span aria-hidden="true">·</span>
                  <span>Voucher: {selectedSettlement.voucherNumber}</span>
                  <span aria-hidden="true">·</span>
                  <span>Invoice: {selectedSettlement.invoiceNumber}</span>
                </div>
              </div>

              {/* Status and Action */}
              <div className="flex items-center gap-2 shrink-0">
                {selectedSettlement.status !== 'PAID_PROCESSED' && (
                  <button
                    onClick={handleProcessDisbursement}
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Approve & Disburse ACH</span>
                  </button>
                )}
              </div>
            </div>

            {/* Factoring Notice of Assignment (NOA) Alert Box */}
            {selectedSettlement.factoringCompany ? (
              <div className="p-3.5 bg-blue-950/40 border border-blue-800/80 rounded-xl flex items-start gap-3">
                <Building className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div className="text-xs leading-relaxed">
                  <span className="font-bold text-white font-mono block">
                    ACTIVE FACTORING NOTICE OF ASSIGNMENT (NOA) ON FILE
                  </span>
                  <p className="text-slate-300 mt-0.5">
                    Carrier accounts receivable are assigned to{' '}
                    <strong className="text-white">
                      {selectedSettlement.factoringCompany.name}
                    </strong>
                    . Remittance MUST be electronically transferred to factoring depository
                    ({selectedSettlement.factoringCompany.remitEmail}) to discharge broker liability.
                  </p>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center gap-2 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Direct Carrier Pay (No Factoring NOA Recorded)</span>
              </div>
            )}

            {/* QuickPay 24-hr Liquidity Option */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <Zap
                  className={`w-5 h-5 mt-0.5 shrink-0 ${
                    selectedSettlement.quickPaySelected ? 'text-amber-400' : 'text-slate-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <span>QuickPay Same-Day ACH Disbursement</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 bg-amber-950 text-amber-300 border border-amber-800 rounded">
                      2.0% Fee
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Overcoming carrier cash flow lag: Pays carrier in 24 hours instead of Net 30.
                  </p>
                </div>
              </div>

              <button
                onClick={handleToggleQuickPay}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
                  selectedSettlement.quickPaySelected
                    ? 'bg-amber-600 hover:bg-amber-500 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                }`}
              >
                {selectedSettlement.quickPaySelected ? 'QuickPay Enabled' : 'Enable QuickPay (2%)'}
              </button>
            </div>

            {/* Audit Checklist & Document Verification */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider">
                Audited Freight Documentation
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300">Signed BOL</span>
                  <span
                    className={`flex items-center gap-1 font-semibold ${
                      selectedSettlement.bolSigned ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {selectedSettlement.bolSigned ? '✓ Verified' : 'Pending'}
                  </span>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300">Receiver POD Stamp</span>
                  <span
                    className={`flex items-center gap-1 font-semibold ${
                      selectedSettlement.podSigned ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {selectedSettlement.podSigned ? '✓ Clean Stamp' : 'Pending Upload'}
                  </span>
                </div>

                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-300">Rate Confirmation</span>
                  <span
                    className={`flex items-center gap-1 font-semibold ${
                      selectedSettlement.rateConSigned ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {selectedSettlement.rateConSigned ? '✓ Executed' : 'Pending Sign'}
                  </span>
                </div>
              </div>
            </div>

            {/* Accessorials & Line Items Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider">
                  Carrier Line Items & Accessorials
                </div>
                <button
                  onClick={() => setShowAddAccessorial(true)}
                  className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-mono"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Accessorial (Detention / Lumper)</span>
                </button>
              </div>

              {/* Add Accessorial Inline Form */}
              {showAddAccessorial && (
                <form
                  onSubmit={handleAddAccessorial}
                  className="p-4 bg-slate-950 border border-blue-500/40 rounded-xl space-y-3"
                >
                  <div className="flex items-center justify-between text-xs font-bold font-mono text-white">
                    <span>Add Verified Accessorial Charge</span>
                    <button
                      type="button"
                      onClick={() => setShowAddAccessorial(false)}
                      className="text-slate-400 hover:text-white"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-400 font-mono block mb-1">
                        Charge Category:
                      </label>
                      <select
                        value={newAccType}
                        onChange={(e) => setNewAccType(e.target.value as any)}
                        className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none"
                      >
                        <option value="DETENTION">Detention ($75/hr after 2h)</option>
                        <option value="LUMPER">Lumper Fee Reimbursement</option>
                        <option value="LAYOVER">Layover Compensation</option>
                        <option value="EXTRA_STOP">Extra Stop / Divert</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 font-mono block mb-1">
                        Amount ($ USD):
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={newAccAmount}
                        onChange={(e) => setNewAccAmount(Number(e.target.value))}
                        className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-xs font-mono text-white focus:outline-none"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 font-mono block mb-1">
                        Customer Re-billable:
                      </label>
                      <div className="flex items-center gap-2 pt-2">
                        <input
                          type="checkbox"
                          id="billableCheck"
                          checked={newAccBillable}
                          onChange={(e) => setNewAccBillable(e.target.checked)}
                          className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-slate-700"
                        />
                        <label htmlFor="billableCheck" className="text-xs text-slate-300">
                          Invoice to Shipper
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 font-mono block mb-1">
                      Audit Description & Receipt Notes:
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Receiver dock delay 3.5 hrs; stamped receiver in/out verified."
                      value={newAccDesc}
                      onChange={(e) => setNewAccDesc(e.target.value)}
                      className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none"
                      required
                    />
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold"
                    >
                      Post Accessorial to Voucher
                    </button>
                  </div>
                </form>
              )}

              {/* Ledger breakdown card */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Carrier Contracted Linehaul:</span>
                  <span className="text-white font-semibold">
                    {formatCurrency(selectedSettlement.carrierBasePay)}
                  </span>
                </div>

                {selectedSettlement.accessorials.map((acc) => (
                  <div key={acc.id} className="flex justify-between py-1 text-slate-300">
                    <span className="truncate pr-2">
                      + {acc.type}: {acc.description}
                    </span>
                    <span className="text-white shrink-0">+{formatCurrency(acc.amount)}</span>
                  </div>
                ))}

                <div className="flex justify-between py-1 text-slate-300">
                  <span className="text-slate-400">Total Carrier Gross Earnings:</span>
                  <span className="text-white font-semibold">
                    {formatCurrency(selectedSettlement.carrierTotalEarned)}
                  </span>
                </div>

                {selectedSettlement.quickPaySelected && (
                  <div className="flex justify-between py-1 text-amber-400">
                    <span>Less QuickPay Accelerated Funding Fee (2.0%):</span>
                    <span>-{formatCurrency(selectedSettlement.quickPayDiscount)}</span>
                  </div>
                )}

                <div className="flex justify-between pt-2 border-t border-slate-800 text-sm font-bold">
                  <span className="text-white">Final Remittance Net Disbursement:</span>
                  <span className="text-emerald-400">
                    {formatCurrency(selectedSettlement.finalCarrierPayout)}
                  </span>
                </div>
              </div>
            </div>

            {/* Shipper Invoice & Net Broker Spread */}
            <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between text-xs font-mono">
              <div>
                <span className="text-slate-400 block">Shipper Invoiced Total:</span>
                <span className="text-white font-bold text-sm">
                  {formatCurrency(selectedSettlement.shipperTotalInvoiced)}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block">Net Brokerage Margin:</span>
                <span className="text-emerald-400 font-bold text-sm">
                  {formatCurrency(selectedSettlement.grossBrokerMargin)} (
                  {selectedSettlement.marginPct.toFixed(1)}%)
                </span>
              </div>

              <div>
                <span className="text-slate-400 block">Settlement Status:</span>
                <span className="text-blue-400 font-bold uppercase">
                  {selectedSettlement.status.replace(/_/g, ' ')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
