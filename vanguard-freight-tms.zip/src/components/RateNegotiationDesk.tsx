import React, { useState } from 'react';
import { RateNegotiation, Load, Carrier } from '../types/freight';
import { formatCurrency, calculateMargin, calculateRPM } from '../utils/freightCalculators';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  ArrowRight,
  Send,
  CheckCircle,
  XCircle,
  MessageSquare,
  Sparkles,
  ShieldAlert,
  Percent,
  Calculator,
  FileCheck,
} from 'lucide-react';

interface RateNegotiationDeskProps {
  negotiations: RateNegotiation[];
  loads: Load[];
  carriers: Carrier[];
  onUpdateNegotiation: (updated: RateNegotiation) => void;
  onAcceptAndBook: (negotiation: RateNegotiation) => void;
  onOpenRateConModal: (load: Load, carrier: Carrier) => void;
}

export const RateNegotiationDesk: React.FC<RateNegotiationDeskProps> = ({
  negotiations,
  loads,
  carriers,
  onUpdateNegotiation,
  onAcceptAndBook,
  onOpenRateConModal,
}) => {
  const [selectedNegId, setSelectedNegId] = useState<string>(
    negotiations[0]?.id || ''
  );
  const activeNeg = negotiations.find((n) => n.id === selectedNegId) || negotiations[0];

  const matchingLoad = loads.find((l) => l.id === activeNeg?.loadId);
  const matchingCarrier = carriers.find((c) => c.id === activeNeg?.carrierId);

  // Counter proposal state
  const [counterRate, setCounterRate] = useState<number>(
    activeNeg ? activeNeg.currentBrokerCounter || activeNeg.brokerTargetRate : 2400
  );
  const [customMessage, setCustomMessage] = useState<string>('');

  // Synchronize counterRate whenever selected negotiation switches
  React.useEffect(() => {
    if (activeNeg) {
      setCounterRate(activeNeg.currentBrokerCounter || activeNeg.brokerTargetRate);
      setCustomMessage('');
    }
  }, [selectedNegId]);

  if (!activeNeg) {
    return (
      <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
        No active rate negotiations currently on the desk.
      </div>
    );
  }

  // Calculate live margin based on proposed counterRate or carrier ask
  const marginWithCurrentCounter = calculateMargin(
    activeNeg.shipperRate,
    counterRate
  );
  const marginWithCarrierAsk = calculateMargin(
    activeNeg.shipperRate,
    activeNeg.currentCarrierOffer
  );

  const handleSendCounter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!counterRate || counterRate <= 0) return;

    const newMsg = {
      id: `msg-${Date.now()}`,
      sender: 'BROKER' as const,
      message:
        customMessage.trim() ||
        `Counter-offer submitted: ${formatCurrency(counterRate)} all-in rate for ${activeNeg.lane}. Standard 2hr detention clause included.`,
      rateProposal: counterRate,
      timestamp: 'Just now',
    };

    const updated: RateNegotiation = {
      ...activeNeg,
      currentBrokerCounter: counterRate,
      currentGrossMargin: activeNeg.shipperRate - counterRate,
      currentMarginPct: ((activeNeg.shipperRate - counterRate) / activeNeg.shipperRate) * 100,
      status: 'COUNTER_SENT',
      round: activeNeg.round + 1,
      thread: [...activeNeg.thread, newMsg],
      updatedAt: 'Just now',
    };

    onUpdateNegotiation(updated);
    setCustomMessage('');
  };

  const handleDecline = () => {
    const newMsg = {
      id: `msg-${Date.now()}`,
      sender: 'BROKER' as const,
      message: `Proposal declined. Rate is outside our authorized shipper ceiling for this corridor.`,
      timestamp: 'Just now',
    };

    const updated: RateNegotiation = {
      ...activeNeg,
      status: 'DECLINED',
      thread: [...activeNeg.thread, newMsg],
      updatedAt: 'Just now',
    };

    onUpdateNegotiation(updated);
  };

  const applyScript = (scriptText: string, suggestedRate?: number) => {
    setCustomMessage(scriptText);
    if (suggestedRate) {
      setCounterRate(suggestedRate);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between p-5 bg-slate-900 border border-slate-800 rounded-xl gap-4">
        <div>
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white tracking-tight">
              Dynamic Rate Negotiation Desk
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Real-time spot rate negotiation, live broker gross margin monitoring, DAT/SONAR lane
            benchmarks, and instant 1-click Rate Confirmation booking.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300">
            Active Bids: <span className="text-white font-bold">{negotiations.length}</span>
          </div>
          <div className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-emerald-400 font-semibold">
            Avg Margin: 17.2%
          </div>
        </div>
      </div>

      {/* Main Grid: Left Bids List + Right Negotiation Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Active Bids Queue */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider">
            Incoming Carrier Bids ({negotiations.length})
          </div>

          <div className="space-y-2">
            {negotiations.map((neg) => {
              const isSelected = neg.id === activeNeg.id;
              const margin = calculateMargin(neg.shipperRate, neg.currentCarrierOffer);

              return (
                <div
                  key={neg.id}
                  onClick={() => setSelectedNegId(neg.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-blue-500 shadow-md ring-1 ring-blue-500/20'
                      : 'bg-slate-900/70 border-slate-800 hover:bg-slate-850 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">
                        {neg.loadNumber} · {neg.carrierName}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {neg.carrierMc}
                      </span>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-bold font-mono text-white">
                        {formatCurrency(neg.currentCarrierOffer)}
                      </div>
                      <div className="text-[10px] text-slate-400">Carrier Ask</div>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-slate-300 font-mono truncate">
                    {neg.lane}
                  </div>

                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono">
                    <span
                      className={`font-medium ${
                        margin.status === 'healthy'
                          ? 'text-emerald-400'
                          : margin.status === 'moderate'
                          ? 'text-amber-400'
                          : 'text-red-400'
                      }`}
                    >
                      Margin: {formatCurrency(margin.marginDollars)} ({margin.marginPct.toFixed(1)}%)
                    </span>

                    <span
                      className={`text-[10px] uppercase font-mono px-1.5 py-0.5 rounded ${
                        neg.status === 'ACCEPTED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : neg.status === 'DECLINED'
                          ? 'bg-red-950 text-red-300 border border-red-800'
                          : neg.status === 'COUNTER_SENT'
                          ? 'bg-blue-950 text-blue-300 border border-blue-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {neg.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Negotiation Workspace */}
        <div className="lg:col-span-8 space-y-6">
          {/* Header of Active Negotiation */}
          <div className="p-6 bg-slate-900 border border-slate-800 rounded-xl space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 border-b border-slate-800 gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold font-mono px-2 py-0.5 bg-blue-950 text-blue-300 border border-blue-800 rounded">
                    {activeNeg.loadNumber}
                  </span>
                  <h3 className="text-base font-bold text-white">{activeNeg.lane}</h3>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-mono">
                  <span>{activeNeg.equipment}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeNeg.miles} Miles</span>
                  <span aria-hidden="true">·</span>
                  <span>Carrier: {activeNeg.carrierName} ({activeNeg.carrierMc})</span>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="shrink-0 text-right">
                <span
                  className={`text-xs uppercase font-mono px-2.5 py-1 rounded-md font-semibold ${
                    activeNeg.status === 'ACCEPTED'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : activeNeg.status === 'DECLINED'
                      ? 'bg-red-950 text-red-300 border border-red-800'
                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                  }`}
                >
                  {activeNeg.status.replace(/_/g, ' ')}
                </span>
                <div className="text-[10px] text-slate-400 font-mono mt-1">
                  Round #{activeNeg.round}
                </div>
              </div>
            </div>

            {/* Lane Market Intelligence Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 font-mono">Shipper Bill Rate</div>
                <div className="text-base font-bold font-mono text-white mt-0.5">
                  {formatCurrency(activeNeg.shipperRate)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  RPM: {calculateRPM(activeNeg.shipperRate, activeNeg.miles)}
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 font-mono">DAT Market Spot Avg</div>
                <div className="text-base font-bold font-mono text-blue-400 mt-0.5">
                  {formatCurrency(activeNeg.benchmarkMarketRate)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  RPM: {calculateRPM(activeNeg.benchmarkMarketRate, activeNeg.miles)}
                </div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 font-mono">Broker Target Rate</div>
                <div className="text-base font-bold font-mono text-emerald-400 mt-0.5">
                  {formatCurrency(activeNeg.brokerTargetRate)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">Planned purchase cost</div>
              </div>

              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400 font-mono">Carrier Current Ask</div>
                <div className="text-base font-bold font-mono text-amber-400 mt-0.5">
                  {formatCurrency(activeNeg.currentCarrierOffer)}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {activeNeg.currentCarrierOffer > activeNeg.brokerTargetRate
                    ? `+$${activeNeg.currentCarrierOffer - activeNeg.brokerTargetRate} over target`
                    : 'Within target range'}
                </div>
              </div>
            </div>

            {/* Live Margin Forecaster Gauge */}
            <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Calculator className="w-4 h-4 text-blue-400" />
                  <span className="font-semibold uppercase tracking-wider">
                    Gross Broker Margin Analyzer
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-slate-400">Projected Net: </span>
                  <span
                    className={`font-bold ${
                      marginWithCurrentCounter.status === 'healthy'
                        ? 'text-emerald-400'
                        : marginWithCurrentCounter.status === 'moderate'
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {formatCurrency(marginWithCurrentCounter.marginDollars)} (
                    {marginWithCurrentCounter.marginPct.toFixed(1)}%)
                  </span>
                </div>
              </div>

              {/* Progress bar visualizer */}
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  className={`h-full transition-all duration-300 ${
                    marginWithCurrentCounter.marginPct >= 16
                      ? 'bg-emerald-500'
                      : marginWithCurrentCounter.marginPct >= 10
                      ? 'bg-amber-500'
                      : 'bg-red-500'
                  }`}
                  style={{
                    width: `${Math.min(100, Math.max(0, marginWithCurrentCounter.marginPct * 3.5))}%`,
                  }}
                />
              </div>

              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0% Breakeven</span>
                <span>10% Floor</span>
                <span>16%+ Target Healthy Margin</span>
                <span>25%+ High Yield</span>
              </div>
            </div>

            {/* Negotiation Message History */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-400 uppercase font-mono tracking-wider">
                Counter-Offer Exchange History
              </div>

              <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                {activeNeg.thread.map((msg) => {
                  const isCarrier = msg.sender === 'CARRIER';

                  return (
                    <div
                      key={msg.id}
                      className={`p-3 rounded-lg border text-xs leading-relaxed ${
                        isCarrier
                          ? 'bg-slate-950 border-slate-800 text-slate-200'
                          : 'bg-blue-950/40 border-blue-800/60 text-blue-100 ml-4'
                      }`}
                    >
                      <div className="flex items-center justify-between pb-1 mb-1 border-b border-slate-800/60 font-mono text-[11px]">
                        <span className="font-semibold text-slate-300">
                          {isCarrier ? `${activeNeg.carrierName} (Carrier)` : 'Vanguard Dispatch Broker'}
                        </span>
                        <div className="flex items-center gap-2">
                          {msg.rateProposal && (
                            <span className="font-bold text-white bg-slate-800 px-1.5 py-0.5 rounded">
                              {formatCurrency(msg.rateProposal)}
                            </span>
                          )}
                          <span className="text-slate-500">{msg.timestamp}</span>
                        </div>
                      </div>
                      <p>{msg.message}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Fast Counterbid Controls & Scripts */}
            {activeNeg.status !== 'ACCEPTED' && activeNeg.status !== 'DECLINED' && (
              <form onSubmit={handleSendCounter} className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white uppercase font-mono tracking-wider">
                    Submit Broker Counter-Offer
                  </span>
                  <div className="flex items-center gap-1.5 font-mono text-xs">
                    <span className="text-slate-400">Quick Increment:</span>
                    <button
                      type="button"
                      onClick={() => setCounterRate((prev) => prev - 50)}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px]"
                    >
                      -$50
                    </button>
                    <button
                      type="button"
                      onClick={() => setCounterRate((prev) => prev + 50)}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px]"
                    >
                      +$50
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setCounterRate(
                          Math.round((activeNeg.currentCarrierOffer + activeNeg.brokerTargetRate) / 2)
                        )
                      }
                      className="px-2 py-0.5 bg-blue-900/60 hover:bg-blue-800 text-blue-200 rounded text-[11px]"
                    >
                      Split Difference ({formatCurrency(Math.round((activeNeg.currentCarrierOffer + activeNeg.brokerTargetRate) / 2))})
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 font-mono block mb-1">
                      Counter Rate ($ USD):
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-slate-400 text-xs font-mono">$</span>
                      <input
                        type="number"
                        step="10"
                        value={counterRate}
                        onChange={(e) => setCounterRate(Number(e.target.value))}
                        className="w-full pl-6 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm font-bold text-white font-mono focus:outline-none focus:border-blue-500"
                        required
                      />
                    </div>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] text-slate-400 font-mono block mb-1">
                      Broker Negotiation Notes / Stipulations:
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Firm all-in rate. Free detention 2 hrs, strict appointment adherence..."
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* Broker Copilot Quick Arguments */}
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono mb-2">
                    <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                    <span>Quick Counter-Arguments:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() =>
                        applyScript(
                          `DAT 7-day average on this lane is ${formatCurrency(activeNeg.benchmarkMarketRate)}. We are firm at ${formatCurrency(activeNeg.brokerTargetRate)} all-in.`,
                          activeNeg.brokerTargetRate
                        )
                      }
                      className="text-[11px] px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 hover:border-slate-700 transition-colors"
                    >
                      "Firm at DAT 7-Day Avg"
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        applyScript(
                          `Standard 2-hour detention policy honored ($75/hr thereafter with stamped in/out BOL). We can lock at ${formatCurrency(counterRate)}.`,
                          counterRate
                        )
                      }
                      className="text-[11px] px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 hover:border-slate-700 transition-colors"
                    >
                      "Guarantee Detention Policy"
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        applyScript(
                          `Palletized clean freight, quick turn dock at receiver. Guaranteed reload options available at destination.`,
                          counterRate
                        )
                      }
                      className="text-[11px] px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 hover:border-slate-700 transition-colors"
                    >
                      "Highlight Quick-Turn Dock"
                    </button>
                  </div>
                </div>

                {/* Submission Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-between pt-2 border-t border-slate-800 gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleDecline}
                      className="px-3.5 py-2 text-xs font-semibold text-red-400 hover:text-red-300 bg-red-950/40 hover:bg-red-950 border border-red-900 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Decline Carrier Ask</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5 text-blue-400" />
                      <span>Send Counter-Offer</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onAcceptAndBook(activeNeg)}
                      className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Accept & Generate Rate Con</span>
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* If Already Accepted / Booked: Rate Con Affordance */}
            {activeNeg.status === 'ACCEPTED' && matchingLoad && matchingCarrier && (
              <div className="p-4 bg-emerald-950/40 border border-emerald-800/80 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <div>
                    <div className="text-xs font-bold text-white uppercase font-mono">
                      Load Successfully Booked & Locked
                    </div>
                    <div className="text-[11px] text-slate-300">
                      Rate Con executed with {activeNeg.carrierName} for {formatCurrency(activeNeg.currentBrokerCounter || activeNeg.currentCarrierOffer)}.
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onOpenRateConModal(matchingLoad, matchingCarrier)}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  <span>View Executed Rate Con</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
