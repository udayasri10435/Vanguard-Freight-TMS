export type EquipmentType = 'Dry Van 53\'' | 'Reefer 53\'' | 'Flatbed 48\'' | 'Step Deck' | 'Power Only';

export type LoadStatus = 'OPEN' | 'BIDDING' | 'DISPATCHED' | 'IN_TRANSIT' | 'DELIVERED' | 'SETTLED';

export type ComplianceTier = 
  | 'APPROVED_PREMIER' 
  | 'STANDARD_APPROVED' 
  | 'REQUIRES_SUPERVISOR_OVERRIDE' 
  | 'DO_NOT_USE_DNU';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export interface LocationPoint {
  city: string;
  state: string;
  zip: string;
  facilityName: string;
  appointmentTime: string;
  contactPhone: string;
  notes?: string;
}

export interface Load {
  id: string;
  loadNumber: string;
  shipperName: string;
  origin: LocationPoint;
  destination: LocationPoint;
  miles: number;
  equipment: EquipmentType;
  weightLbs: number;
  palletCount: number;
  commodity: string;
  tempRequirement?: string;
  shipperRate: number; // What customer pays the broker
  targetCarrierRate: number; // Target broker purchase rate
  maxCarrierRate: number; // Broker ceiling purchase rate
  currentCarrierRate?: number; // Final agreed purchase rate
  status: LoadStatus;
  syndicatedBoards: ('DAT One' | 'Truckstop.com' | 'Direct Fleet')[];
  assignedCarrierId?: string;
  assignedCarrierName?: string;
  assignedCarrierMc?: string;
  driverName?: string;
  driverPhone?: string;
  truckNumber?: string;
  trailerNumber?: string;
  pickupDate: string;
  deliveryDate: string;
  tracking: {
    currentMilestone: string;
    progressPct: number;
    eta: string;
    lastCheckCall: string;
    temperatureActual?: string;
    detentionRiskHours?: number;
    notes?: string;
  };
  rateConNumber?: string;
  createdAt: string;
}

export interface CarrierInsurance {
  autoLiability: number; // min $1,000,000
  cargoLiability: number; // min $100,000
  expiresAt: string;
  policyNumber: string;
  underwriter: string;
  coiVerified: boolean;
}

export interface CarrierFraudAudit {
  score: number; // 0-100 (100 = safest, <60 = high risk)
  riskLevel: RiskLevel;
  doubleBrokerAlert: boolean;
  chameleonScore: number; // similarity to previously revoked authorities
  addressFlag: boolean; // e.g. Virtual mailbox / UPS Store registered as physical yard
  phoneDomainMismatch: boolean; // Free gmail/yahoo domain vs registered domain
  fraudFlags: string[];
}

export interface Carrier {
  id: string;
  mcNumber: string;
  dotNumber: string;
  legalName: string;
  dbaName?: string;
  contactName: string;
  phone: string;
  email: string;
  homeTerminal: string;
  authorityAgeYears: number;
  fmcsaStatus: 'AUTHORIZED' | 'NOT_AUTHORIZED' | 'PENDING_REVOCATION';
  safetyRating: 'SATISFACTORY' | 'CONDITIONAL' | 'UNRATED';
  oosDriverRate: number; // Nat Avg ~5.5%
  oosVehicleRate: number; // Nat Avg ~21.4%
  insurance: CarrierInsurance;
  fraudAudit: CarrierFraudAudit;
  complianceTier: ComplianceTier;
  fleetSize: number;
  preferredLanes: string[];
  totalLoadsCompleted: number;
  onTimeDeliveryRate: number; // e.g. 98.4
}

export interface RateNegotiation {
  id: string;
  loadId: string;
  loadNumber: string;
  carrierId: string;
  carrierName: string;
  carrierMc: string;
  lane: string;
  equipment: EquipmentType;
  miles: number;
  shipperRate: number;
  benchmarkMarketRate: number;
  brokerTargetRate: number;
  initialAskRate: number;
  currentCarrierOffer: number;
  currentBrokerCounter: number;
  currentGrossMargin: number;
  currentMarginPct: number;
  status: 'PENDING_BROKER_REVIEW' | 'COUNTER_SENT' | 'ACCEPTED' | 'DECLINED';
  round: number;
  carrierContact: {
    name: string;
    phone: string;
    email: string;
  };
  thread: {
    id: string;
    sender: 'CARRIER' | 'BROKER';
    message: string;
    rateProposal?: number;
    timestamp: string;
  }[];
  updatedAt: string;
}

export interface AccessorialItem {
  id: string;
  type: 'DETENTION' | 'LUMPER' | 'LAYOVER' | 'EXTRA_STOP' | 'HAZMAT';
  description: string;
  amount: number;
  billableToCustomer: boolean;
  receiptVerified: boolean;
}

export interface SettlementRecord {
  id: string;
  loadId: string;
  loadNumber: string;
  carrierId: string;
  carrierName: string;
  carrierMc: string;
  shipperName: string;
  lane: string;
  equipment: EquipmentType;
  deliveredDate: string;
  
  // Financials
  shipperBaseRate: number;
  shipperTotalInvoiced: number;
  
  carrierBasePay: number;
  accessorials: AccessorialItem[];
  carrierTotalEarned: number;
  
  // Payment terms
  quickPaySelected: boolean;
  quickPayFeePct: number; // typically 2%
  quickPayDiscount: number;
  finalCarrierPayout: number;
  
  grossBrokerMargin: number;
  marginPct: number;
  
  factoringCompany?: {
    name: string;
    noaVerified: boolean;
    remitEmail: string;
  };
  
  // Documents & Audit
  podSigned: boolean;
  bolSigned: boolean;
  rateConSigned: boolean;
  status: 'AWAITING_POD' | 'AUDIT_VERIFIED' | 'READY_FOR_PAYMENT' | 'PAID_PROCESSED';
  paymentMethod: 'ACH_QUICKPAY_SAME_DAY' | 'STANDARD_NET_30' | 'FACTORING_WIRE';
  voucherNumber: string;
  invoiceNumber: string;
  paymentDueDate: string;
  notes?: string;
}

export interface MarketLaneRate {
  id: string;
  lane: string;
  originState: string;
  destState: string;
  equipment: EquipmentType;
  miles: number;
  spotAverage: number;
  rpm: number; // Rate per mile
  weekChangePct: number;
  capacityRatio: string; // e.g. "3.2 loads / truck"
  tenderRejectionRate: number; // e.g. 4.8%
}
