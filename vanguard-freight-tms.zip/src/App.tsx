import React, { useState } from 'react';
import {
  INITIAL_CARRIERS,
  INITIAL_LOADS,
  INITIAL_NEGOTIATIONS,
  INITIAL_SETTLEMENTS,
  MARKET_BENCHMARKS,
} from './data/mockFreightData';
import { Carrier, Load, RateNegotiation, SettlementRecord } from './types/freight';
import { LoadBoard } from './components/LoadBoard';
import { CarrierVetting } from './components/CarrierVetting';
import { RateNegotiationDesk } from './components/RateNegotiationDesk';
import { SettlementLedger } from './components/SettlementLedger';
import { FreightMarketInsights } from './components/FreightMarketInsights';
import { DocumentModal } from './components/DocumentModal';
import {
  Layers,
  ShieldCheck,
  DollarSign,
  CreditCard,
  GitBranch,
  Truck,
  Plus,
  Bell,
  Search,
} from 'lucide-react';
import { formatCurrency } from './utils/freightCalculators';

type ActiveView = 'LOAD_BOARD' | 'CARRIER_VETTING' | 'RATE_NEGOTIATION' | 'SETTLEMENT' | 'MARKET_INSIGHTS';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('LOAD_BOARD');
  const [loads, setLoads] = useState<Load[]>(INITIAL_LOADS);
  const [carriers, setCarriers] = useState<Carrier[]>(INITIAL_CARRIERS);
  const [negotiations, setNegotiations] = useState<RateNegotiation[]>(INITIAL_NEGOTIATIONS);
  const [settlements, setSettlements] = useState<SettlementRecord[]>(INITIAL_SETTLEMENTS);

  // Document Modal state
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    type: 'RATE_CON' | 'SETTLEMENT_VOUCHER' | 'SHIPPER_INVOICE';
    load?: Load;
    carrier?: Carrier;
    settlement?: SettlementRecord;
  }>({
    isOpen: false,
    type: 'RATE_CON',
  });

  // Load Handlers
  const handleAddLoad = (newLoad: Load) => {
    setLoads((prev) => [newLoad, ...prev]);
  };

  const handleUpdateLoad = (updatedLoad: Load) => {
    setLoads((prev) => prev.map((l) => (l.id === updatedLoad.id ? updatedLoad : l)));
  };

  // Carrier Handlers
  const handleUpdateCarrier = (updatedCarrier: Carrier) => {
    setCarriers((prev) => prev.map((c) => (c.id === updatedCarrier.id ? updatedCarrier : c)));
  };

  const handleAddCarrier = (newCarrier: Carrier) => {
    setCarriers((prev) => [newCarrier, ...prev]);
  };

  // Negotiation Handlers
  const handleUpdateNegotiation = (updatedNeg: RateNegotiation) => {
    setNegotiations((prev) => prev.map((n) => (n.id === updatedNeg.id ? updatedNeg : n)));
  };

  // 1-Click Accept & Book Load from Negotiation Desk
  const handleAcceptAndBook = (negotiation: RateNegotiation) => {
    const agreedRate = negotiation.currentBrokerCounter || negotiation.currentCarrierOffer;
    const rateConNum = `RC-${negotiation.loadNumber}-${negotiation.carrierMc.replace(/[^0-9]/g, '')}`;

    // 1. Update Negotiation state
    const updatedNeg: RateNegotiation = {
      ...negotiation,
      status: 'ACCEPTED',
      currentBrokerCounter: agreedRate,
      currentGrossMargin: negotiation.shipperRate - agreedRate,
      currentMarginPct: ((negotiation.shipperRate - agreedRate) / negotiation.shipperRate) * 100,
      thread: [
        ...negotiation.thread,
        {
          id: `msg-${Date.now()}`,
          sender: 'BROKER',
          message: `Offer of ${formatCurrency(agreedRate)} accepted. Rate Confirmation ${rateConNum} generated and dispatched. Load locked.`,
          rateProposal: agreedRate,
          timestamp: 'Just now',
        },
      ],
      updatedAt: 'Just now',
    };
    handleUpdateNegotiation(updatedNeg);

    // 2. Update Load state to DISPATCHED
    const targetLoad = loads.find((l) => l.id === negotiation.loadId);
    if (targetLoad) {
      const updatedLoad: Load = {
        ...targetLoad,
        status: 'DISPATCHED',
        assignedCarrierId: negotiation.carrierId,
        assignedCarrierName: negotiation.carrierName,
        assignedCarrierMc: negotiation.carrierMc,
        currentCarrierRate: agreedRate,
        rateConNumber: rateConNum,
        driverName: 'Assigned Dispatch Driver',
        driverPhone: negotiation.carrierContact.phone,
        tracking: {
          ...targetLoad.tracking,
          currentMilestone: 'Carrier Dispatched - En Route to Shipper',
          notes: `Booked via Dynamic Negotiation at ${formatCurrency(agreedRate)}. Rate Con dispatched.`,
        },
      };
      handleUpdateLoad(updatedLoad);

      // 3. Create initial settlement record
      const newSettlement: SettlementRecord = {
        id: `set-${Date.now()}`,
        loadId: targetLoad.id,
        loadNumber: targetLoad.loadNumber,
        carrierId: negotiation.carrierId,
        carrierName: negotiation.carrierName,
        carrierMc: negotiation.carrierMc,
        shipperName: targetLoad.shipperName,
        lane: `${targetLoad.origin.city}, ${targetLoad.origin.state} to ${targetLoad.destination.city}, ${targetLoad.destination.state}`,
        equipment: targetLoad.equipment,
        deliveredDate: 'Pending Delivery',
        shipperBaseRate: targetLoad.shipperRate,
        shipperTotalInvoiced: targetLoad.shipperRate,
        carrierBasePay: agreedRate,
        accessorials: [],
        carrierTotalEarned: agreedRate,
        quickPaySelected: true,
        quickPayFeePct: 2.0,
        quickPayDiscount: (agreedRate * 2) / 100,
        finalCarrierPayout: agreedRate - (agreedRate * 2) / 100,
        grossBrokerMargin: targetLoad.shipperRate - agreedRate,
        marginPct: ((targetLoad.shipperRate - agreedRate) / targetLoad.shipperRate) * 100,
        podSigned: false,
        bolSigned: true,
        rateConSigned: true,
        status: 'AWAITING_POD',
        paymentMethod: 'ACH_QUICKPAY_SAME_DAY',
        voucherNumber: `VCH-${targetLoad.loadNumber}`,
        invoiceNumber: `INV-${targetLoad.loadNumber}`,
        paymentDueDate: targetLoad.deliveryDate,
      };
      setSettlements((prev) => [newSettlement, ...prev]);

      // 4. Open Rate Con document preview for user review
      const assignedCarrier = carriers.find((c) => c.id === negotiation.carrierId);
      setModalState({
        isOpen: true,
        type: 'RATE_CON',
        load: updatedLoad,
        carrier: assignedCarrier,
      });
    }
  };

  // Settlement Handlers
  const handleUpdateSettlement = (updated: SettlementRecord) => {
    setSettlements((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  };

  // Open Document Modal
  const handleOpenDocument = (
    type: 'RATE_CON' | 'SETTLEMENT_VOUCHER' | 'SHIPPER_INVOICE',
    data?: any
  ) => {
    if (type === 'RATE_CON') {
      setModalState({
        isOpen: true,
        type: 'RATE_CON',
        load: data?.load || loads[0],
        carrier: data?.carrier || carriers[0],
      });
    } else {
      setModalState({
        isOpen: true,
        type,
        settlement: data || settlements[0],
        load: loads.find((l) => l.id === data?.loadId) || loads[0],
      });
    }
  };

  const handleNavigateToNegotiation = (loadId: string) => {
    setActiveView('RATE_NEGOTIATION');
  };

  const pendingNegotiationsCount = negotiations.filter(
    (n) => n.status === 'PENDING_BROKER_REVIEW' || n.status === 'COUNTER_SENT'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Top Bar Contract: Zone 1 (Brand) — Zone 2 (4-6 Nav Links) — Zone 3 (1-2 Actions) */}
      <header className="sticky top-0 z-40 flex items-center justify-between px-6 py-3.5 bg-slate-950/95 border-b border-slate-800 backdrop-blur-md">
        {/* Zone 1: Single text element brand wordmark */}
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
          <span className="text-base font-bold tracking-tight text-white font-sans">
            Vanguard Freight TMS
          </span>
        </div>

        {/* Zone 2: Navigation Links (Single-line, text links with clean hover / active states) */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => setActiveView('LOAD_BOARD')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeView === 'LOAD_BOARD'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Load Boards & Dispatch
          </button>

          <button
            onClick={() => setActiveView('CARRIER_VETTING')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeView === 'CARRIER_VETTING'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Carrier Vetting & Fraud Shield
          </button>

          <button
            onClick={() => setActiveView('RATE_NEGOTIATION')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeView === 'RATE_NEGOTIATION'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <span>Rate Negotiation Desk</span>
            {pendingNegotiationsCount > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] font-mono bg-blue-600 text-white rounded-full">
                {pendingNegotiationsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveView('SETTLEMENT')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeView === 'SETTLEMENT'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Settlement & Accounting
          </button>

          <button
            onClick={() => setActiveView('MARKET_INSIGHTS')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeView === 'MARKET_INSIGHTS'
                ? 'bg-slate-800 text-white shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            Fragmentation Insights
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono text-slate-400">
            <span>Desk #04 · Chicago</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400">FMCSA Synced</span>
          </div>

          <button
            onClick={() => {
              setActiveView('LOAD_BOARD');
            }}
            className="px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap shadow-sm flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Post Load</span>
          </button>
        </div>
      </header>

      {/* Mobile Nav Bar for smaller viewports */}
      <div className="md:hidden flex items-center gap-1 p-2 bg-slate-900 border-b border-slate-800 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveView('LOAD_BOARD')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeView === 'LOAD_BOARD' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Load Boards
        </button>
        <button
          onClick={() => setActiveView('CARRIER_VETTING')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeView === 'CARRIER_VETTING' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Vetting & Fraud
        </button>
        <button
          onClick={() => setActiveView('RATE_NEGOTIATION')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeView === 'RATE_NEGOTIATION' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Rate Desk ({pendingNegotiationsCount})
        </button>
        <button
          onClick={() => setActiveView('SETTLEMENT')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeView === 'SETTLEMENT' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Settlement
        </button>
        <button
          onClick={() => setActiveView('MARKET_INSIGHTS')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${
            activeView === 'MARKET_INSIGHTS' ? 'bg-slate-800 text-white' : 'text-slate-400'
          }`}
        >
          Insights
        </button>
      </div>

      {/* Main Workspace Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeView === 'LOAD_BOARD' && (
          <LoadBoard
            loads={loads}
            carriers={carriers}
            onAddLoad={handleAddLoad}
            onUpdateLoad={handleUpdateLoad}
            onNavigateToNegotiation={handleNavigateToNegotiation}
            onOpenRateConModal={(load, carrier) =>
              handleOpenDocument('RATE_CON', { load, carrier })
            }
          />
        )}

        {activeView === 'CARRIER_VETTING' && (
          <CarrierVetting
            carriers={carriers}
            onUpdateCarrier={handleUpdateCarrier}
            onAddCarrier={handleAddCarrier}
          />
        )}

        {activeView === 'RATE_NEGOTIATION' && (
          <RateNegotiationDesk
            negotiations={negotiations}
            loads={loads}
            carriers={carriers}
            onUpdateNegotiation={handleUpdateNegotiation}
            onAcceptAndBook={handleAcceptAndBook}
            onOpenRateConModal={(load, carrier) =>
              handleOpenDocument('RATE_CON', { load, carrier })
            }
          />
        )}

        {activeView === 'SETTLEMENT' && (
          <SettlementLedger
            settlements={settlements}
            onUpdateSettlement={handleUpdateSettlement}
            onOpenDocument={(type, record) => handleOpenDocument(type, record)}
          />
        )}

        {activeView === 'MARKET_INSIGHTS' && (
          <FreightMarketInsights marketRates={MARKET_BENCHMARKS} />
        )}
      </main>

      {/* Document Viewer Modal (Rate Confirmation, Remittance Voucher, Shipper Invoice) */}
      {modalState.isOpen && (
        <DocumentModal
          type={modalState.type}
          load={modalState.load}
          carrier={modalState.carrier}
          settlement={modalState.settlement}
          onClose={() => setModalState({ isOpen: false, type: 'RATE_CON' })}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-xs text-slate-500 font-mono flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span>Vanguard Freight TMS</span>
          <span aria-hidden="true">·</span>
          <span>Unified Logistics Operating System</span>
        </div>
        <div>
          <span>FMCSA Property Broker MC-994102-B · TIA Member #88419</span>
        </div>
      </footer>
    </div>
  );
}
